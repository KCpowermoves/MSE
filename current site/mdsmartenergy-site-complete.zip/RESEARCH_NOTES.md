# Maryland Smart Energy - Research Notes

## EmPOWER Maryland Program Overview

EmPOWER Maryland is a utility-funded energy efficiency program created by the Energy Efficiency Act of 2008. The program provides incentives to help Maryland businesses and households save energy and money.

**Participating Utilities:**
- Baltimore Gas & Electric (BGE)
- Potomac Edison Company (PE)
- Delmarva Power & Light (DPL)
- Potomac Electric Power Company (PEPCO)
- Washington Gas Light Company
- Southern Maryland Electric Cooperative (SMECO)

The program is funded by charges already included on customer energy bills, meaning there is no additional out-of-pocket cost to participate.

## Service Areas Covered

Maryland Smart Energy serves the following utility territories:
- BGE (Baltimore Gas & Electric)
- Pepco (Potomac Electric Power Company)
- Delmarva Power
- SMECO (Southern Maryland Electric Cooperative)

## HVAC Tune-Up Program

**Benefits:**
- Save 5% to 20% on energy costs
- Enhance comfort and safety for occupants
- Improve reliability of HVAC equipment
- Extend equipment lifespan through preventative maintenance

**Incentive Structure (BGE):**
- Units <3 Tons: $40/ton
- Units 3-20 Tons: $160/unit
- Units >20-50 Tons: $260/unit
- Units >50 Tons: $350/unit

**Eligible Systems:**
- Unitary systems (heating, cooling, fans in one package)
- Direct-expansion rooftop units
- Split systems

**Maintenance Frequency:** Units are eligible for tune-up incentive once every 3 years

## Building Tune-Up Program

Comprehensive evaluations and adjustments to enhance overall building energy efficiency. Includes HVAC optimization, controls adjustments, and other building system improvements.

## Energy Benchmarking Services

**Overview:**
Energy benchmarking is the process of tracking a building's annual energy use and comparing it against past performance and similar building types. This helps identify energy-saving opportunities and manage operational costs.

**Key Tools:**
- ENERGY STAR Portfolio Manager (free EPA tool)
- Utility-specific benchmarking tools

**Maryland Building Energy Performance Standards (BEPS):**
- Applies to buildings 35,000+ square feet
- Annual reporting requirement starting June 1, 2025
- Third-party verification required (first year, then every 5 years)
- Helps track progress toward Maryland's 2040 zero net direct GHG emissions goal

**Utility Data Systems:**
- BGE Energy Usage Data System
- Delmarva Power Energy Usage Data System
- Pepco Energy Usage Data System
- SMECO Energy Benchmarking Tool

## Lighting Services

EmPOWER Maryland offers incentives for:
- LED fixture upgrades
- LED exit sign replacements
- Occupancy and lighting controls
- Street lighting upgrades (for property owners)

## Energy Efficiency Updates

General energy efficiency improvements covered under EmPOWER programs:
- Weatherization
- Insulation improvements
- HVAC system upgrades
- Lighting retrofits
- Building controls optimization
- Refrigeration improvements

## Key Messaging Points

1. **Zero Cost to Participate:** All programs are funded by utility charges already on customer bills
2. **Licensed and Insured:** Services provided by qualified, licensed professionals
3. **Environmental Responsibility:** Reducing energy consumption lowers carbon footprint
4. **Business Savings:** Potential savings of up to 10% on energy usage
5. **Equipment Lifespan:** Proper maintenance extends HVAC system life, delaying costly replacements
6. **Compliance:** Benchmarking services help buildings comply with Maryland BEPS requirements

## Target Customer Types

- Hotels
- Restaurants
- Convenience stores
- Religious institutions
- Schools and universities
- Commercial office buildings
- Multi-family residential buildings
- Government facilities
