import { useEffect } from "react";
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch, useLocation } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Layout from "./components/Layout";
import HvacTuneUp from "./pages/services/HvacTuneUp";
import BuildingTuneUp from "./pages/services/BuildingTuneUp";
import Lighting from "./pages/services/Lighting";
import EnergyEfficiency from "./pages/services/EnergyEfficiency";
import Benchmarking from "./pages/services/Benchmarking";
import CommunitySolar from "./pages/services/CommunitySolar";
import EnergySupply from "./pages/services/EnergySupply";
import About from "./pages/About";
import Contact from "./pages/Contact";
import Blog from "./pages/Blog";
import Article from "./pages/Article";
import PrivacyPolicy from "./pages/PrivacyPolicy";
import TermsOfService from "./pages/TermsOfService";
import AdminDashboard from "./pages/AdminDashboard";
import AdminBlogEditor from "./pages/AdminBlogEditor";

function Router() {
  const [location] = useLocation();

  // Scroll to top when route changes
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location]);

  return (
    <Layout>
      <Switch>
        <Route path={"/"} component={Home} />
        <Route path={"/services/hvac-tune-up"} component={HvacTuneUp} />
        <Route path={"/services/building-tune-up"} component={BuildingTuneUp} />
        <Route path={"/services/lighting"} component={Lighting} />
        <Route path={"/services/energy-efficiency"} component={EnergyEfficiency} />
        <Route path={"/services/benchmarking"} component={Benchmarking} />
        <Route path={"/services/community-solar"} component={CommunitySolar} />
        <Route path={"/services/energy-supply"} component={EnergySupply} />
        <Route path={"/about"} component={About} />
        <Route path={"/contact"} component={Contact} />
        <Route path={"/blog"} component={Blog} />
        <Route path={"/blog/:slug"} component={Article} />
        <Route path={"/privacy-policy"} component={PrivacyPolicy} />
        <Route path={"/terms-of-service"} component={TermsOfService} />
        <Route path={"/admin"} component={AdminDashboard} />
        <Route path={"/admin/blog/new"} component={AdminBlogEditor} />
        <Route path={"/admin/blog/:id"} component={AdminBlogEditor} />
        <Route path={"/404"} component={NotFound} />
        {/* Final fallback route */}
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
