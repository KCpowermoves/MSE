import { Menu, X, ChevronDown } from "lucide-react";
import { Link } from "wouter";
import { useState } from "react";
import ServiceFormModal from "./ServiceFormModal";

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [servicesDropdownOpen, setServicesDropdownOpen] = useState(false);
  const [isFormOpen, setIsFormOpen] = useState(false);

  const services = [
    { href: "/services/hvac-tune-up", label: "HVAC Tune-Up" },
    { href: "/services/building-tune-up", label: "Building Tune-Up" },
    { href: "/services/lighting", label: "Lighting" },
    { href: "/services/energy-supply", label: "Energy Supply" },
    { href: "/services/community-solar", label: "Community Solar" },
    { href: "/services/benchmarking", label: "Benchmarking Services" },
  ];

  const navLinks = [
    { href: "/", label: "Home" },
    { label: "Services", submenu: services },
    { href: "/blog", label: "Blog" },
    { href: "/about", label: "About" },
    { href: "/contact", label: "Contact" },
  ];

  return (
    <div className="flex flex-col min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <Link href="/">
              <a className="flex items-center gap-4">
                <img src="https://d2xsxph8kpxj0f.cloudfront.net/310519663343730640/awFmGyrrsiLMgk7vjDfYKy/marylandsmartenergy-logo-final_cfa9716b.jpg" alt="Maryland Smart Energy" className="h-20 w-auto" />
                <div className="hidden sm:flex flex-col">
                  <span className="text-[#001F3F] font-bold text-lg whitespace-nowrap">Maryland Smart Energy</span>
                  <span className="text-[#C41E3A] font-semibold text-xs whitespace-nowrap">Smarter Buildings. Lower Bills.</span>
                </div>
              </a>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center gap-8">
              {navLinks.map((link, index) => (
                <div key={index} className="relative group">
                  {link.submenu ? (
                    <>
                      <button className="text-gray-700 hover:text-[#C41E3A] transition-colors font-medium text-sm flex items-center gap-1">
                        {link.label}
                        <ChevronDown size={16} />
                      </button>
                      {/* Dropdown Menu */}
                      <div className="absolute left-0 mt-0 w-48 bg-white border border-gray-200 rounded-lg shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 py-2">
                        {link.submenu.map((item) => (
                          <Link key={item.href} href={item.href}>
                            <a className="block px-4 py-2 text-gray-700 hover:bg-[#C41E3A] hover:text-white transition-colors text-sm">
                              {item.label}
                            </a>
                          </Link>
                        ))}
                      </div>
                    </>
                  ) : (
                    <Link href={link.href!}>
                      <a className="text-gray-700 hover:text-[#C41E3A] transition-colors font-medium text-sm">
                        {link.label}
                      </a>
                    </Link>
                  )}
                </div>
              ))}
            </nav>

            {/* Phone CTA */}
            <a href="tel:(301) 888-7090" className="hidden md:flex items-center justify-center bg-[#C41E3A] text-white px-8 py-4 rounded hover:bg-[#A01729] transition-colors font-medium flex-col gap-1">
              <span className="text-sm">Call Now</span>
              <span className="text-xl font-bold">(301) 888-7090</span>
            </a>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 hover:bg-gray-100 rounded"
            >
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>

          {/* Mobile Navigation */}
          {mobileMenuOpen && (
            <nav className="lg:hidden mt-4 pb-4 border-t border-gray-200 pt-4 flex flex-col gap-3">
              {navLinks.map((link, index) => (
                <div key={index}>
                  {link.submenu ? (
                    <>
                      <button
                        onClick={() => setServicesDropdownOpen(!servicesDropdownOpen)}
                        className="text-gray-700 hover:text-[#C41E3A] transition-colors font-medium text-sm flex items-center gap-1 w-full"
                      >
                        {link.label}
                        <ChevronDown size={16} className={`transform transition-transform ${servicesDropdownOpen ? "rotate-180" : ""}`} />
                      </button>
                      {servicesDropdownOpen && (
                        <div className="ml-4 mt-2 flex flex-col gap-2">
                          {link.submenu.map((item) => (
                            <Link key={item.href} href={item.href}>
                              <a
                                className="text-gray-700 hover:text-[#C41E3A] transition-colors text-sm"
                                onClick={() => setMobileMenuOpen(false)}
                              >
                                {item.label}
                              </a>
                            </Link>
                          ))}
                        </div>
                      )}
                    </>
                  ) : (
                    <Link href={link.href!}>
                      <a
                        className="text-gray-700 hover:text-[#C41E3A] transition-colors font-medium text-sm"
                        onClick={() => setMobileMenuOpen(false)}
                      >
                        {link.label}
                      </a>
                    </Link>
                  )}
                </div>
              ))}
              <Link href="/contact">
                <a
                  className="bg-[#C41E3A] text-white px-4 py-2 rounded hover:bg-[#A01729] transition-colors font-medium text-center mt-2"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Get Started
                </a>
              </Link>
            </nav>
          )}
        </div>
      </header>

      {/* Promotional Banner */}
      <style>{`
        @keyframes pulse-10s {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.7; }
        }
        .banner-pulse {
          animation: pulse-10s 2s cubic-bezier(0.4, 0, 0.6, 1) 5 forwards;
        }
      `}</style>
      <div className="bg-[#FFB81C] text-[#001F3F] py-2 px-4 banner-pulse">
        <button
          onClick={() => setIsFormOpen(true)}
          className="w-full text-center hover:opacity-90 transition-opacity"
        >
          <p className="text-lg md:text-2xl font-bold">Now Available!</p>
          <p className="text-lg md:text-2xl font-bold">$0 Energy Walkthrough And HVAC Tune-Up</p>
          <p className="text-xs md:text-sm">*$0 After Rebates If Applicable</p>
        </button>
      </div>

      {/* Main Content */}
      <main className="flex-grow">
        {children}
      </main>

      {/* Service Form Modal */}
      <ServiceFormModal
        isOpen={isFormOpen}
        onClose={() => setIsFormOpen(false)}
        serviceName="Energy Walk-Through & HVAC Cleaning"
        isPaperform={true}
        paperformId="rxtuneupsite"
      />

      {/* Footer */}
      <footer className="bg-[#001F3F] text-white mt-16">
        <div className="container mx-auto px-4 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            {/* Company Info */}
            <div>
              <h3 className="font-bold text-lg mb-4">Maryland Smart Energy</h3>
              <p className="text-gray-300 text-sm mb-4">
                Helping Maryland businesses reduce energy costs through EmPOWER Maryland programs.
              </p>
              <div className="flex gap-4">
                <a href="#" className="text-gray-300 hover:text-[#FFB81C] transition-colors">
                  <span className="sr-only">Facebook</span>
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M19 3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14m-.5 15.5v-5.3a3.26 3.26 0 0 0-3.26-3.26c-.85 0-1.84.52-2.32 1.39v-1.2h-2.5v8.5h2.5v-4.34c0-.92.6-1.9 1.97-1.9 1.22 0 1.61.88 1.61 2.26v3.98h2.5M6.88 8.56a1.68 1.68 0 0 0 1.68-1.68c0-.93-.75-1.69-1.68-1.69-.93 0-1.69.76-1.69 1.69 0 .93.76 1.68 1.69 1.68m1.39 9.94v-8.5H5.5v8.5h2.77z" />
                  </svg>
                </a>
              </div>
            </div>

            {/* Services Links */}
            <div>
              <h4 className="font-bold mb-4">Services</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="/services/hvac-tune-up">
                    <a className="text-gray-300 hover:text-[#FFB81C] transition-colors">HVAC Tune-Up</a>
                  </Link>
                </li>
                <li>
                  <Link href="/services/building-tune-up">
                    <a className="text-gray-300 hover:text-[#FFB81C] transition-colors">Building Tune-Up</a>
                  </Link>
                </li>
                <li>
                  <Link href="/services/lighting">
                    <a className="text-gray-300 hover:text-[#FFB81C] transition-colors">Lighting</a>
                  </Link>
                </li>
                <li>
                  <Link href="/services/energy-supply">
                    <a className="text-gray-300 hover:text-[#FFB81C] transition-colors">Energy Supply</a>
                  </Link>
                </li>
              </ul>
            </div>

            {/* Resources Links */}
            <div>
              <h4 className="font-bold mb-4">Resources</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="/about">
                    <a className="text-gray-300 hover:text-[#FFB81C] transition-colors">About Us</a>
                  </Link>
                </li>
                <li>
                  <Link href="/blog">
                    <a className="text-gray-300 hover:text-[#FFB81C] transition-colors">Blog</a>
                  </Link>
                </li>
                <li>
                  <Link href="/contact">
                    <a className="text-gray-300 hover:text-[#FFB81C] transition-colors">Contact</a>
                  </Link>
                </li>
              </ul>
            </div>

            {/* Contact Info */}
            <div>
              <h4 className="font-bold mb-4">Contact</h4>
              <p className="text-gray-300 text-sm mb-2">
                <a href="tel:(301) 888-7090" className="hover:text-[#FFB81C] transition-colors">
                  (301) 888-7090
                </a>
              </p>
              <p className="text-gray-300 text-sm">
                <a href="mailto:service@mdsmartenergy.com" className="hover:text-[#FFB81C] transition-colors">
                  service@mdsmartenergy.com
                </a>
              </p>
            </div>
          </div>

          {/* Bottom Footer */}
          <div className="border-t border-gray-700 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-300 text-sm mb-4 md:mb-0">
              &copy; 2024 Maryland Smart Energy. All rights reserved.
            </p>
            <div className="flex gap-6 text-sm">
              <Link href="/privacy-policy">
                <a className="text-gray-300 hover:text-[#FFB81C] transition-colors">Privacy Policy</a>
              </Link>
              <Link href="/terms-of-service">
                <a className="text-gray-300 hover:text-[#FFB81C] transition-colors">Terms of Service</a>
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
