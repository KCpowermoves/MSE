import { Link } from "wouter";
import { CheckCircle2, Users, Target, Award } from "lucide-react";

export default function About() {
  const values = [
    {
      icon: Target,
      title: "Mission-Driven",
      description: "We're committed to helping Maryland businesses reduce energy costs and environmental impact.",
    },
    {
      icon: Award,
      title: "Expert Team",
      description: "Our licensed, bonded, and insured professionals bring years of energy efficiency expertise.",
    },
    {
      icon: Users,
      title: "Customer-Focused",
      description: "We prioritize your satisfaction and success, providing responsive support every step of the way.",
    },
  ];

  const highlights = [
    "Licensed, bonded, and insured professionals",
    "Serving BGE, Pepco, Delmarva Power, and SMECO territories",
    "Certified in energy efficiency and building optimization",
    "Experienced with EmPOWER Maryland programs",
    "Track record of successful projects across Maryland",
    "Dedicated customer service team",
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-[#001F3F] to-[#1B4A7F] text-white py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">About Maryland Smart Energy</h1>
            <p className="text-lg text-gray-200">
              Dedicated to helping Maryland businesses achieve energy efficiency, reduce operating costs, 
              and support our state's sustainability goals.
            </p>
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold text-[#001F3F] mb-6">Our Mission</h2>
            <p className="text-gray-600 text-lg leading-relaxed mb-6">
              Maryland Smart Energy is dedicated to helping businesses enhance their energy efficiency 
              and reduce operational costs through comprehensive HVAC, building, and energy efficiency 
              evaluation programs. We partner with Maryland's leading utilities to deliver no-cost 
              energy solutions funded by the EmPOWER Maryland program.
            </p>
            <p className="text-gray-600 text-lg leading-relaxed">
              Our mission is to make energy efficiency accessible to every business in Maryland, 
              regardless of size. We believe that energy efficiency should be easy, affordable, and 
              beneficial for both businesses and the environment.
            </p>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-[#001F3F] mb-12">
            Our Core Values
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            {values.map((value, index) => {
              const Icon = value.icon;
              return (
                <div key={index} className="bg-white p-8 rounded-lg shadow-md text-center">
                  <Icon className="w-12 h-12 text-[#C41E3A] mx-auto mb-4" />
                  <h3 className="text-lg font-bold text-[#001F3F] mb-3">{value.title}</h3>
                  <p className="text-gray-600 text-sm leading-relaxed">{value.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-[#001F3F] mb-12">
            Why Choose Maryland Smart Energy?
          </h2>
          <div className="max-w-3xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {highlights.map((highlight, index) => (
                <div key={index} className="flex gap-4">
                  <CheckCircle2 className="w-6 h-6 text-[#C41E3A] flex-shrink-0 mt-1" />
                  <p className="text-gray-700 font-medium">{highlight}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Expertise Section */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-[#001F3F] mb-12">
            Our Expertise
          </h2>
          <div className="max-w-4xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-xl font-bold text-[#001F3F] mb-4">Energy Efficiency Services</h3>
                <ul className="space-y-3">
                  {[
                    "HVAC tune-ups and optimization",
                    "Building comprehensive evaluations",
                    "Lighting upgrades and controls",
                    "Energy benchmarking and analysis",
                    "Building automation systems",
                    "Refrigeration improvements",
                  ].map((service, index) => (
                    <li key={index} className="flex gap-3">
                      <CheckCircle2 className="w-5 h-5 text-[#C41E3A] flex-shrink-0 mt-0.5" />
                      <span className="text-gray-600">{service}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <h3 className="text-xl font-bold text-[#001F3F] mb-4">Service Territories</h3>
                <ul className="space-y-3">
                  {[
                    "Baltimore Gas & Electric (BGE)",
                    "Potomac Electric Power Company (Pepco)",
                    "Delmarva Power & Light",
                    "Southern Maryland Electric Cooperative (SMECO)",
                    "Serving all of Maryland",
                  ].map((territory, index) => (
                    <li key={index} className="flex gap-3">
                      <CheckCircle2 className="w-5 h-5 text-[#C41E3A] flex-shrink-0 mt-0.5" />
                      <span className="text-gray-600">{territory}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Customer Types Section */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-[#001F3F] mb-12">
            Who We Serve
          </h2>
          <div className="max-w-4xl mx-auto">
            <p className="text-center text-gray-600 mb-8 leading-relaxed">
              We work with businesses of all sizes across Maryland, from small offices to large facilities. 
              Our services are particularly valuable for:
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[
                "Hotels and hospitality businesses",
                "Restaurants and food service",
                "Retail stores and shopping centers",
                "Office buildings and corporate facilities",
                "Schools and educational institutions",
                "Religious institutions and nonprofits",
                "Government buildings",
                "Multi-family residential properties",
              ].map((customer, index) => (
                <div key={index} className="flex gap-4">
                  <CheckCircle2 className="w-6 h-6 text-[#C41E3A] flex-shrink-0 mt-1" />
                  <p className="text-gray-700 font-medium">{customer}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Contact CTA */}
      <section className="bg-[#001F3F] text-white py-16 md:py-24">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Work With Us?
          </h2>
          <p className="text-lg text-gray-200 mb-8 max-w-2xl mx-auto">
            Contact Maryland Smart Energy today to discuss your energy efficiency goals and discover 
            how we can help you save money while supporting Maryland's sustainability mission.
          </p>
          <Link href="/contact">
            <a className="inline-block bg-[#C41E3A] hover:bg-[#A01729] text-white font-bold py-4 px-10 rounded-lg transition-colors text-lg">
              Get in Touch
            </a>
          </Link>
        </div>
      </section>
    </div>
  );
}
