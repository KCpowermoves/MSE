import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { useLocation, useRoute } from "wouter";
import { ArrowLeft, Save } from "lucide-react";
import { Link } from "wouter";

interface BlogPostForm {
  slug: string;
  title: string;
  excerpt: string;
  content: string;
  category: string;
  author: string;
  featured: number;
  published: number;
  publishedAt?: Date;
}

export default function AdminBlogEditor() {
  const [, setLocation] = useLocation();
  const [, params] = useRoute("/admin/blog/:id");
  const postId = params?.id ? parseInt(params.id) : null;
  
  const [form, setForm] = useState<BlogPostForm>({
    slug: "",
    title: "",
    excerpt: "",
    content: "",
    category: "",
    author: "Maryland Smart Energy",
    featured: 0,
    published: 0,
  });

  // Fetch existing post if editing
  const { data: existingPost, isLoading } = trpc.blog.getById.useQuery(
    { id: postId! },
    { enabled: !!postId }
  );

  // Populate form with existing post data
  useEffect(() => {
    if (existingPost) {
      setForm({
        slug: existingPost.slug,
        title: existingPost.title,
        excerpt: existingPost.excerpt || "",
        content: existingPost.content,
        category: existingPost.category || "",
        author: existingPost.author || "Maryland Smart Energy",
        featured: existingPost.featured,
        published: existingPost.published,
      });
    }
  }, [existingPost]);

  // Create or update blog post
  const createMutation = trpc.blog.create.useMutation();
  const updateMutation = trpc.blog.update.useMutation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!form.title.trim() || !form.content.trim()) {
      alert("Title and content are required");
      return;
    }

    try {
      if (postId) {
        await updateMutation.mutateAsync({
          id: postId,
          ...form,
        });
      } else {
        await createMutation.mutateAsync(form);
      }

      // Redirect to dashboard
      setLocation("/admin");
    } catch (error) {
      console.error("Error saving blog post:", error);
      alert("Error saving blog post: " + (error instanceof Error ? error.message : "Unknown error"));
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <p className="text-gray-600">Loading...</p>
      </div>
    );
  }

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value, type } = e.target;
    const finalValue = type === "checkbox" ? (e.target as HTMLInputElement).checked ? 1 : 0 : value;
    setForm((prev) => ({
      ...prev,
      [name]: finalValue,
    }));
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/admin">
              <a className="inline-flex items-center gap-2 text-gray-600 hover:text-gray-900">
                <ArrowLeft className="w-5 h-5" />
                Back
              </a>
            </Link>
            <h1 className="text-3xl font-bold text-[#001F3F]">
              {postId ? "Edit Blog Post" : "Create New Blog Post"}
            </h1>
          </div>
          <button
            onClick={handleSubmit}
            disabled={createMutation.isPending || updateMutation.isPending}
            className="inline-flex items-center gap-2 bg-[#C41E3A] text-white px-6 py-2 rounded hover:bg-[#A01729] disabled:opacity-50"
          >
            <Save className="w-5 h-5" />
            {createMutation.isPending || updateMutation.isPending ? "Saving..." : "Save Post"}
          </button>
        </div>
      </header>

      {/* Content */}
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow p-8 space-y-6">
          {/* Title */}
          <div>
            <label className="block text-sm font-semibold text-gray-900 mb-2">
              Post Title *
            </label>
            <input
              type="text"
              name="title"
              value={form.title}
              onChange={handleChange}
              required
              className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#C41E3A]"
              placeholder="Enter post title"
            />
          </div>

          {/* Slug */}
          <div>
            <label className="block text-sm font-semibold text-gray-900 mb-2">
              URL Slug *
            </label>
            <input
              type="text"
              name="slug"
              value={form.slug}
              onChange={handleChange}
              required
              className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#C41E3A]"
              placeholder="url-slug-for-post"
            />
            <p className="text-xs text-gray-600 mt-1">Used in the URL: /blog/{form.slug}</p>
          </div>

          {/* Excerpt */}
          <div>
            <label className="block text-sm font-semibold text-gray-900 mb-2">
              Excerpt
            </label>
            <textarea
              name="excerpt"
              value={form.excerpt}
              onChange={handleChange}
              rows={3}
              className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#C41E3A]"
              placeholder="Brief summary of the post (shown in blog listing)"
            ></textarea>
          </div>

          {/* Content */}
          <div>
            <label className="block text-sm font-semibold text-gray-900 mb-2">
              Content * (Markdown supported)
            </label>
            <textarea
              name="content"
              value={form.content}
              onChange={handleChange}
              required
              rows={15}
              className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#C41E3A] font-mono text-sm"
              placeholder="Write your blog post content here. Markdown is supported."
            ></textarea>
          </div>

          {/* Metadata */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Category */}
            <div>
              <label className="block text-sm font-semibold text-gray-900 mb-2">
                Category
              </label>
              <select
                name="category"
                value={form.category}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#C41E3A]"
              >
                <option value="">Select a category</option>
                <option value="HVAC">HVAC</option>
                <option value="Energy Efficiency">Energy Efficiency</option>
                <option value="Benchmarking">Benchmarking</option>
                <option value="Solar">Solar</option>
                <option value="Lighting">Lighting</option>
                <option value="Tips">Tips & Tricks</option>
                <option value="News">News</option>
              </select>
            </div>

            {/* Author */}
            <div>
              <label className="block text-sm font-semibold text-gray-900 mb-2">
                Author
              </label>
              <input
                type="text"
                name="author"
                value={form.author}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#C41E3A]"
                placeholder="Author name"
              />
            </div>
          </div>

          {/* Options */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <input
                type="checkbox"
                id="featured"
                name="featured"
                checked={form.featured === 1}
                onChange={handleChange}
                className="w-4 h-4 rounded border-gray-300"
              />
              <label htmlFor="featured" className="text-sm font-medium text-gray-900">
                Feature this post (show on homepage)
              </label>
            </div>

            <div className="flex items-center gap-3">
              <input
                type="checkbox"
                id="published"
                name="published"
                checked={form.published === 1}
                onChange={handleChange}
                className="w-4 h-4 rounded border-gray-300"
              />
              <label htmlFor="published" className="text-sm font-medium text-gray-900">
                Publish this post (make it visible to the public)
              </label>
            </div>
          </div>

          {/* Submit Buttons */}
          <div className="flex gap-4 pt-6 border-t">
            <button
              type="submit"
              disabled={createMutation.isPending || updateMutation.isPending}
              className="flex-1 bg-[#C41E3A] text-white px-6 py-3 rounded font-medium hover:bg-[#A01729] disabled:opacity-50"
            >
              {createMutation.isPending || updateMutation.isPending ? "Saving..." : "Save Blog Post"}
            </button>
            <Link href="/admin">
              <a className="flex-1 bg-gray-200 text-gray-900 px-6 py-3 rounded font-medium hover:bg-gray-300 text-center">
                Cancel
              </a>
            </Link>
          </div>
        </form>
      </div>
    </div>
  );
}
