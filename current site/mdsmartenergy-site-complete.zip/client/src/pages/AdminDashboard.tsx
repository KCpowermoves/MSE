import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Plus, Edit2, Trash2, Eye, BarChart3, Mail, LogOut } from "lucide-react";
import { Link } from "wouter";

export default function AdminDashboard() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [activeTab, setActiveTab] = useState<"overview" | "blog" | "analytics" | "leads">("overview");
  const [days, setDays] = useState(30);

  const loginMutation = trpc.adminAuth.login.useMutation();
  const dashboardQuery = trpc.analytics.getDashboardSummary.useQuery({ days }, { enabled: isAuthenticated });
  const blogListQuery = trpc.blog.listAll.useQuery(undefined, { enabled: isAuthenticated });
  const deleteMutation = trpc.blog.delete.useMutation({
    onSuccess: () => {
      blogListQuery.refetch();
    },
  });
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    try {
      await loginMutation.mutateAsync({ password });
      setIsAuthenticated(true);
      setPassword("");
    } catch (err) {
      setError("Invalid password");
      setPassword("");
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setPassword("");
    setError("");
  };

  // Login form
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="bg-white p-8 rounded-lg shadow-md w-full max-w-md">
          <h1 className="text-3xl font-bold text-[#001F3F] mb-2">Admin Dashboard</h1>
          <p className="text-gray-600 mb-6">Enter the admin password to continue</p>

          <form onSubmit={handleLogin}>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter password"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg mb-4 focus:outline-none focus:ring-2 focus:ring-[#C41E3A]"
            />
            {error && <p className="text-red-600 text-sm mb-4">{error}</p>}
            <button
              type="submit"
              disabled={loginMutation.isPending}
              className="w-full bg-[#C41E3A] text-white py-2 rounded-lg hover:bg-[#A01729] font-medium disabled:opacity-50"
            >
              {loginMutation.isPending ? "Logging in..." : "Log In"}            </button>
          </form>

          <Link href="/">
            <a className="inline-block mt-6 text-[#C41E3A] hover:underline">← Back to Home</a>
          </Link>
        </div>
      </div>
    );
  }

  // Dashboard view
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-[#001F3F]">Admin Dashboard</h1>
            <p className="text-gray-600">Manage your blog and track website analytics</p>
          </div>
          <button
            onClick={handleLogout}
            className="flex items-center gap-2 bg-gray-200 text-gray-800 px-4 py-2 rounded hover:bg-gray-300"
          >
            <LogOut size={18} />
            Log Out
          </button>
        </div>
      </header>

      {/* Tabs */}
      <div className="container mx-auto px-4 py-6">
        <div className="flex gap-4 mb-6 border-b border-gray-200">
          {(["overview", "blog", "analytics", "leads"] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 font-medium border-b-2 transition ${
                activeTab === tab
                  ? "border-[#C41E3A] text-[#C41E3A]"
                  : "border-transparent text-gray-600 hover:text-gray-900"
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </div>

        {/* Overview Tab */}
        {activeTab === "overview" && (
          <div>
            {dashboardQuery.isLoading ? (
              <p className="text-gray-600">Loading...</p>
            ) : dashboardQuery.data ? (
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="bg-white p-6 rounded-lg shadow">
                  <p className="text-gray-600 text-sm">Total Page Views</p>
                  <p className="text-3xl font-bold text-[#001F3F]">{dashboardQuery.data.pageViews.total}</p>
                </div>
                <div className="bg-white p-6 rounded-lg shadow">
                  <p className="text-gray-600 text-sm">New Leads</p>
                  <p className="text-3xl font-bold text-[#C41E3A]">{dashboardQuery.data.leads.total}</p>
                </div>
                <div className="bg-white p-6 rounded-lg shadow">
                  <p className="text-gray-600 text-sm">Unique Pages</p>
                  <p className="text-3xl font-bold text-[#DAA520]">{dashboardQuery.data.pageViews.uniquePages}</p>
                </div>
                <div className="bg-white p-6 rounded-lg shadow">
                  <p className="text-gray-600 text-sm">Avg. Daily Views</p>
                  <p className="text-3xl font-bold text-[#001F3F]">{Math.round(dashboardQuery.data.pageViews.total / days)}</p>
                </div>
              </div>
            ) : null}
          </div>
        )}

        {/* Blog Tab */}
        {activeTab === "blog" && (
          <div>
            <Link href="/admin/blog/new">
              <a className="inline-flex items-center gap-2 bg-[#C41E3A] text-white px-4 py-2 rounded hover:bg-[#A01729] mb-6">
                <Plus size={18} />
                New Post
              </a>
            </Link>

            {blogListQuery.isLoading ? (
              <p className="text-gray-600">Loading...</p>
            ) : blogListQuery.data && blogListQuery.data.length > 0 ? (
              <div className="space-y-4">
                {blogListQuery.data.map((post) => (
                  <div key={post.id} className="bg-white p-4 rounded-lg shadow flex justify-between items-center">
                    <div>
                      <h3 className="font-semibold text-gray-900">{post.title}</h3>
                      <p className="text-sm text-gray-600">By {post.author} • {new Date(post.createdAt).toLocaleDateString()}</p>
                    </div>
                    <div className="flex gap-2">
                      <Link href={`/admin/blog/${post.id}`}>
                        <a className="p-2 text-gray-600 hover:text-[#C41E3A]">
                          <Edit2 size={18} />
                        </a>
                      </Link>
                      <button
                        onClick={() => {
                          if (confirm("Are you sure you want to delete this post?")) {
                            deleteMutation.mutate({ id: post.id });
                          }
                        }}
                        disabled={deleteMutation.isPending}
                        className="p-2 text-gray-600 hover:text-red-600 disabled:opacity-50"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-600">No blog posts yet. Create one to get started!</p>
            )}
          </div>
        )}

        {/* Analytics Tab */}
        {activeTab === "analytics" && (
          <div>
            <div className="bg-white p-6 rounded-lg shadow">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Traffic Analytics</h2>
              <p className="text-gray-600">Analytics data will appear here as visitors browse your site.</p>
            </div>
          </div>
        )}

        {/* Leads Tab */}
        {activeTab === "leads" && (
          <div>
            <div className="bg-white p-6 rounded-lg shadow">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Recent Leads</h2>
              <p className="text-gray-600">Contact form submissions will appear here.</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
