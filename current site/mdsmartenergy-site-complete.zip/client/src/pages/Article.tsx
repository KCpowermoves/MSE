import { Link, useRoute } from "wouter";
import { Calendar, User, ArrowLeft } from "lucide-react";

export default function Article() {
  const [, params] = useRoute("/blog/:slug");
  const slug = params?.slug;

  const articles: Record<string, any> = {
    "hvac-maintenance-tips": {
      title: "5 HVAC Maintenance Tips to Maximize Efficiency",
      author: "Maryland Smart Energy",
      date: "March 15, 2026",
      category: "HVAC",
      image: "🔧",
      content: `
        <h2>Keep Your HVAC System Running at Peak Efficiency</h2>
        <p>Your HVAC system is one of the largest energy consumers in your facility. Regular maintenance is essential to ensure it operates efficiently and lasts as long as possible. Here are five maintenance tips that can help you maximize efficiency and reduce energy costs.</p>

        <h3>1. Change Air Filters Regularly</h3>
        <p>Dirty air filters restrict airflow and force your HVAC system to work harder. Replace filters every 1-3 months depending on usage and filter type. This simple step can improve efficiency by 5-15% and extend equipment life.</p>

        <h3>2. Clean Condenser Coils</h3>
        <p>Outdoor condenser coils accumulate dirt and debris over time, reducing heat transfer efficiency. Schedule annual professional cleaning to maintain optimal performance and prevent system strain.</p>

        <h3>3. Check Refrigerant Levels</h3>
        <p>Low refrigerant levels indicate a leak and force your system to work harder. Have a professional check refrigerant levels annually and repair any leaks promptly to maintain efficiency.</p>

        <h3>4. Inspect and Seal Ductwork</h3>
        <p>Leaky ducts waste conditioned air before it reaches occupied spaces. Sealing duct leaks can improve efficiency by 10-20% and reduce energy costs significantly.</p>

        <h3>5. Optimize Thermostat Settings</h3>
        <p>Programmable or smart thermostats can reduce energy consumption by automatically adjusting temperatures based on occupancy and time of day. Consider upgrading to a smart thermostat for maximum savings.</p>

        <h2>Schedule Your HVAC Tune-Up Today</h2>
        <p>Our EmPOWER Maryland HVAC tune-up program includes all these maintenance tasks at no cost to you. Contact us today to schedule your free tune-up and start saving on energy costs.</p>
      `,
    },
    "energy-benchmarking-guide": {
      title: "Complete Guide to Energy Benchmarking for Maryland Businesses",
      author: "Maryland Smart Energy",
      date: "March 10, 2026",
      category: "Benchmarking",
      image: "📊",
      content: `
        <h2>Understanding Energy Benchmarking</h2>
        <p>Energy benchmarking is the process of measuring and tracking your building's energy consumption and comparing it against past performance and similar buildings. This guide will help you understand benchmarking and why it's essential for your business.</p>

        <h3>What is Energy Benchmarking?</h3>
        <p>Benchmarking provides visibility into how your building uses energy. By tracking consumption over time and comparing against similar facilities, you can identify where energy is being wasted and prioritize improvements.</p>

        <h3>Why Benchmark Your Building?</h3>
        <p>Benchmarking helps you understand energy consumption patterns, identify efficiency opportunities, track progress over time, and meet regulatory requirements like Maryland's Building Energy Performance Standards (BEPS).</p>

        <h3>Maryland BEPS Requirements</h3>
        <p>Buildings 35,000 square feet and larger must benchmark annually and submit reports to the Maryland Department of Environment starting June 1, 2025. Third-party verification is required every 5 years.</p>

        <h3>Getting Started with Benchmarking</h3>
        <p>We help you set up benchmarking in ENERGY STAR Portfolio Manager, collect energy data from your utility companies, analyze results, and ensure compliance with BEPS requirements.</p>

        <h2>Contact Us for Benchmarking Services</h2>
        <p>Our no-cost benchmarking services are covered by EmPOWER Maryland. Let us help you understand your building's energy performance and identify savings opportunities.</p>
      `,
    },
    "led-lighting-benefits": {
      title: "The Complete Benefits of LED Lighting Upgrades",
      author: "Maryland Smart Energy",
      date: "March 5, 2026",
      category: "Lighting",
      image: "💡",
      content: `
        <h2>Transform Your Facility with LED Lighting</h2>
        <p>LED lighting technology has revolutionized energy efficiency. By upgrading to LEDs, you can dramatically reduce energy consumption while improving light quality and safety. Here's everything you need to know about LED benefits.</p>

        <h3>Energy Savings</h3>
        <p>LEDs use 75% less energy than incandescent bulbs and 50% less than fluorescent fixtures. For a typical facility, this translates to significant reductions in lighting energy costs.</p>

        <h3>Long Lifespan</h3>
        <p>LED bulbs last 25-50 times longer than traditional bulbs, reducing replacement frequency and maintenance costs. Many LEDs last 50,000+ hours, meaning less frequent replacements and lower labor costs.</p>

        <h3>Improved Light Quality</h3>
        <p>Modern LEDs provide excellent color rendering and brightness control. You can choose from various color temperatures to match your facility's needs and create the desired ambiance.</p>

        <h3>Reduced Heat Output</h3>
        <p>LEDs produce less heat than traditional lighting, reducing cooling costs in summer months. This is particularly beneficial for facilities with significant cooling loads.</p>

        <h3>Smart Controls</h3>
        <p>Combine LEDs with occupancy sensors and daylight harvesting controls to achieve additional savings of 20-30% by ensuring lights are only on when needed.</p>

        <h2>Schedule Your Lighting Audit</h2>
        <p>Our lighting efficiency services are covered by EmPOWER Maryland. Contact us for a free lighting audit and discover how much you can save with LED upgrades.</p>
      `,
    },
  };

  const article = articles[slug || ""];

  if (!article) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-[#001F3F] mb-4">Article Not Found</h1>
          <Link href="/blog">
            <a className="text-[#C41E3A] hover:underline font-semibold">Back to Blog</a>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-[#001F3F] to-[#1B4A7F] text-white py-16 md:py-24">
        <div className="container mx-auto px-4">
          <Link href="/blog" className="inline-flex items-center gap-2 text-gray-200 hover:text-white mb-6 transition-colors">
            <ArrowLeft className="w-5 h-5" />
            Back to Blog
          </Link>
          <div className="max-w-3xl">
            <div className="mb-4">
              <span className="inline-block bg-[#C41E3A] text-white text-sm font-semibold px-3 py-1 rounded-full">
                {article.category}
              </span>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-6">{article.title}</h1>
            <div className="flex flex-wrap gap-6 text-gray-200">
              <div className="flex items-center gap-2">
                <User className="w-5 h-5" />
                <span>{article.author}</span>
              </div>
              <div className="flex items-center gap-2">
                <Calendar className="w-5 h-5" />
                <span>{article.date}</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Article Content */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            {/* Featured Image */}
            <div className="bg-gradient-to-br from-[#C41E3A] to-[#A01729] rounded-lg h-96 flex items-center justify-center text-9xl mb-12">
              {article.image}
            </div>

            {/* Article Body */}
            <div className="prose prose-lg max-w-none mb-12">
              <div
                dangerouslySetInnerHTML={{
                  __html: article.content
                    .replace(/<h2>/g, '<h2 className="text-3xl font-bold text-[#001F3F] mt-8 mb-4">')
                    .replace(/<h3>/g, '<h3 className="text-2xl font-bold text-[#001F3F] mt-6 mb-3">')
                    .replace(/<p>/g, '<p className="text-gray-600 leading-relaxed mb-4">'),
                }}
              />
            </div>

            {/* CTA */}
            <div className="bg-blue-50 border-l-4 border-[#C41E3A] p-8 rounded mb-12">
              <h3 className="text-xl font-bold text-[#001F3F] mb-3">Ready to Improve Your Facility?</h3>
              <p className="text-gray-600 mb-4">
                Our energy efficiency services are covered by EmPOWER Maryland. Contact us today for a free assessment.
              </p>
              <Link href="/contact" className="inline-block bg-[#C41E3A] hover:bg-[#A01729] text-white font-bold py-3 px-8 rounded-lg transition-colors">
                Get Your Free Assessment
              </Link>
            </div>

            {/* Related Articles */}
            <div className="border-t border-gray-200 pt-12">
              <h3 className="text-2xl font-bold text-[#001F3F] mb-8">Related Articles</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {Object.entries(articles)
                  .filter(([key]) => key !== slug)
                  .slice(0, 2)
                  .map(([key, art]) => (
                    <Link key={key} href={`/blog/${key}`} className="group block">
                        <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
                          <div className="bg-gradient-to-br from-[#C41E3A] to-[#A01729] h-32 flex items-center justify-center text-4xl">
                            {art.image}
                          </div>
                          <div className="p-4">
                            <h4 className="font-bold text-[#001F3F] group-hover:text-[#C41E3A] transition-colors line-clamp-2">
                              {art.title}
                            </h4>
                            <p className="text-xs text-gray-500 mt-2">{art.date}</p>
                          </div>
                        </div>
                    </Link>
                  ))}
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
