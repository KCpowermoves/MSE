import { Link } from "wouter";
import { Calendar, User } from "lucide-react";

export default function Blog() {
  const articles = [
    {
      slug: "hvac-maintenance-tips",
      title: "5 HVAC Maintenance Tips to Maximize Efficiency",
      excerpt: "Learn how proper maintenance can improve your HVAC system's performance and extend its lifespan.",
      author: "Maryland Smart Energy",
      date: "March 15, 2026",
      category: "HVAC",
      image: "🔧",
    },
    {
      slug: "energy-benchmarking-guide",
      title: "Complete Guide to Energy Benchmarking for Maryland Businesses",
      excerpt: "Understand how benchmarking works and why it's essential for meeting BEPS compliance requirements.",
      author: "Maryland Smart Energy",
      date: "March 10, 2026",
      category: "Benchmarking",
      image: "📊",
    },
    {
      slug: "led-lighting-benefits",
      title: "The Complete Benefits of LED Lighting Upgrades",
      excerpt: "Discover how LED lighting can reduce your energy costs by up to 75% while improving light quality.",
      author: "Maryland Smart Energy",
      date: "March 5, 2026",
      category: "Lighting",
      image: "💡",
    },
    {
      slug: "empower-maryland-programs",
      title: "Maximizing Your EmPOWER Maryland Benefits",
      excerpt: "A comprehensive overview of all available EmPOWER Maryland programs and how to access them.",
      author: "Maryland Smart Energy",
      date: "February 28, 2026",
      category: "Energy Efficiency",
      image: "⚡",
    },
    {
      slug: "building-efficiency-checklist",
      title: "Building Energy Efficiency Checklist for Facility Managers",
      excerpt: "A practical checklist to help you identify and prioritize energy efficiency improvements.",
      author: "Maryland Smart Energy",
      date: "February 20, 2026",
      category: "Energy Efficiency",
      image: "✓",
    },
    {
      slug: "compressed-air-savings",
      title: "Hidden Savings: Compressed Air System Optimization",
      excerpt: "Learn how to identify and fix compressed air leaks that are costing you thousands annually.",
      author: "Maryland Smart Energy",
      date: "February 15, 2026",
      category: "Energy Efficiency",
      image: "💨",
    },
  ];

  const categories = ["All", "HVAC", "Lighting", "Benchmarking", "Energy Efficiency"];

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-[#001F3F] to-[#1B4A7F] text-white py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Energy Efficiency Blog</h1>
            <p className="text-lg text-gray-200">
              Expert insights, tips, and industry news to help you reduce energy costs and improve your facility's efficiency.
            </p>
          </div>
        </div>
      </section>

      {/* Blog Content */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          {/* Category Filter */}
          <div className="mb-12 flex flex-wrap gap-3 justify-center">
            {categories.map((category) => (
              <button
                key={category}
                className={`px-6 py-2 rounded-full font-medium transition-colors ${
                  category === "All"
                    ? "bg-[#C41E3A] text-white"
                    : "bg-gray-200 text-gray-700 hover:bg-[#C41E3A] hover:text-white"
                }`}
              >
                {category}
              </button>
            ))}
          </div>

          {/* Articles Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {articles.map((article) => (
              <Link key={article.slug} href={`/blog/` + article.slug} className="group block">
                  <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow h-full flex flex-col">
                    {/* Article Image */}
                    <div className="bg-gradient-to-br from-[#C41E3A] to-[#A01729] h-48 flex items-center justify-center text-6xl">
                      {article.image}
                    </div>

                    {/* Article Content */}
                    <div className="p-6 flex flex-col flex-grow">
                      {/* Category Badge */}
                      <div className="mb-3">
                        <span className="inline-block bg-[#C41E3A] text-white text-xs font-semibold px-3 py-1 rounded-full">
                          {article.category}
                        </span>
                      </div>

                      {/* Title */}
                      <h3 className="text-lg font-bold text-[#001F3F] mb-3 group-hover:text-[#C41E3A] transition-colors line-clamp-2">
                        {article.title}
                      </h3>

                      {/* Excerpt */}
                      <p className="text-gray-600 text-sm leading-relaxed mb-4 flex-grow line-clamp-3">
                        {article.excerpt}
                      </p>

                      {/* Meta Information */}
                      <div className="border-t border-gray-200 pt-4 flex items-center justify-between text-xs text-gray-500">
                        <div className="flex items-center gap-4">
                          <div className="flex items-center gap-1">
                            <Calendar className="w-4 h-4" />
                            <span>{article.date}</span>
                          </div>
                        </div>
                        <span className="text-[#C41E3A] font-semibold group-hover:translate-x-1 transition-transform">
                          Read More →
                        </span>
                      </div>
                    </div>
                  </div>
              </Link>
            ))}
          </div>

          {/* Load More */}
          <div className="text-center mt-16">
            <button className="bg-[#C41E3A] hover:bg-[#A01729] text-white font-bold py-3 px-8 rounded-lg transition-colors">
              Load More Articles
            </button>
          </div>
        </div>
      </section>

      {/* Newsletter CTA */}
      <section className="bg-[#001F3F] text-white py-16 md:py-24">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Stay Updated on Energy Efficiency
          </h2>
          <p className="text-lg text-gray-200 mb-8 max-w-2xl mx-auto">
            Subscribe to our blog for the latest energy efficiency tips, industry news, and EmPOWER Maryland updates.
          </p>
          <form className="max-w-md mx-auto flex gap-3">
            <input
              type="email"
              placeholder="Enter your email"
              className="flex-grow px-4 py-3 rounded-lg focus:outline-none"
              required
            />
            <button
              type="submit"
              className="bg-[#C41E3A] hover:bg-[#A01729] text-white font-bold py-3 px-8 rounded-lg transition-colors"
            >
              Subscribe
            </button>
          </form>
        </div>
      </section>
    </div>
  );
}
