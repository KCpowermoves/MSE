import { useState } from "react";
import { Phone, Mail, Clock, MapPin } from "lucide-react";

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    company: "",
    serviceType: "",
    message: "",
  });

  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState("");

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!formData.name || !formData.email || !formData.message) {
      setError("Please fill in all required fields");
      return;
    }

    try {
      setSubmitted(true);
      setFormData({
        name: "",
        email: "",
        phone: "",
        company: "",
        serviceType: "",
        message: "",
      });

      setTimeout(() => setSubmitted(false), 5000);
    } catch (err) {
      setError("Failed to submit form. Please try again.");
    }
  };

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-[#001F3F] to-[#1B4A7F] text-white py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Contact Us</h1>
            <p className="text-lg text-gray-200">
              Ready to reduce your energy costs? Get in touch with our team today. We are here to help 
              you navigate EmPOWER Maryland programs and find the perfect energy efficiency solution for your business.
            </p>
          </div>
        </div>
      </section>

      {/* Contact Information */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
            {[
              {
                icon: Phone,
                title: "Phone",
                content: "(301) 888-7090",
                link: "tel:+13018887090",
              },
              {
                icon: Mail,
                title: "Email",
                content: "service@mdsmartenergy.com",
                link: "mailto:service@mdsmartenergy.com",
              },
              {
                icon: Clock,
                title: "Hours",
                content: "Mon-Fri: 9:00AM - 5:00PM EST",
              },
              {
                icon: MapPin,
                title: "Service Area",
                content: "All of Maryland",
              },
            ].map((item, index) => {
              const Icon = item.icon;
              return (
                <div key={index} className="bg-white p-6 rounded-lg shadow-md text-center">
                  <Icon className="w-12 h-12 text-[#C41E3A] mx-auto mb-4" />
                  <h3 className="font-bold text-[#001F3F] mb-2">{item.title}</h3>
                  {item.link ? (
                    <a href={item.link} className="text-gray-600 hover:text-[#C41E3A] transition-colors block break-words overflow-hidden">
                      {item.content}
                    </a>
                  ) : (
                    <p className="text-gray-600 break-words overflow-hidden">{item.content}</p>
                  )}
                </div>
              );
            })}
          </div>

          {/* Contact Form */}
          <div className="max-w-2xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold text-center text-[#001F3F] mb-12">
              Send Us a Message
            </h2>

            {submitted && (
              <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg">
                <p className="text-green-800 font-semibold">Thank you for your message!</p>
                <p className="text-green-700 text-sm mt-1">
                  We will get back to you as soon as possible.
                </p>
              </div>
            )}

            {error && (
              <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-red-800 font-semibold">{error}</p>
              </div>
            )}

            <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-md p-8 border border-gray-200">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                  <label className="block text-sm font-semibold text-[#001F3F] mb-2">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-[#C41E3A]"
                    placeholder="Your name"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-[#001F3F] mb-2">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-[#C41E3A]"
                    placeholder="your@email.com"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                  <label className="block text-sm font-semibold text-[#001F3F] mb-2">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-[#C41E3A]"
                    placeholder="(301) 555-0000"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-[#001F3F] mb-2">
                    Company Name
                  </label>
                  <input
                    type="text"
                    name="company"
                    value={formData.company}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-[#C41E3A]"
                    placeholder="Your company"
                  />
                </div>
              </div>

              <div className="mb-6">
                <label className="block text-sm font-semibold text-[#001F3F] mb-2">
                  Service Interest
                </label>
                <select
                  name="serviceType"
                  value={formData.serviceType}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-[#C41E3A]"
                >
                  <option value="">Select a service...</option>
                  <option value="hvac">HVAC Tune-Up</option>
                  <option value="building">Building Tune-Up</option>
                  <option value="lighting">Lighting Upgrade</option>
                  <option value="efficiency">Energy Efficiency</option>
                  <option value="benchmarking">Benchmarking</option>
                  <option value="other">Other</option>
                </select>
              </div>

              <div className="mb-6">
                <label className="block text-sm font-semibold text-[#001F3F] mb-2">
                  Message *
                </label>
                <textarea
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  rows={5}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-[#C41E3A]"
                  placeholder="Tell us about your energy efficiency needs..."
                  required
                />
              </div>

              <button
                type="submit"
                className="w-full bg-[#C41E3A] hover:bg-[#A01729] text-white font-bold py-3 px-6 rounded-lg transition-colors"
              >
                Send Message
              </button>
            </form>

            <p className="text-center text-gray-600 text-sm mt-6">
              We typically respond to inquiries within 24 hours during business days.
            </p>
          </div>
        </div>
      </section>

      {/* Service Territory */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-[#001F3F] mb-12">
            Our Service Territory
          </h2>
          <div className="max-w-3xl mx-auto">
            <p className="text-center text-gray-600 mb-8 leading-relaxed">
              Maryland Smart Energy serves businesses throughout Maryland through partnerships with 
              the state's leading utility companies. We help customers access EmPOWER Maryland programs 
              in the following service territories:
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[
                "Baltimore Gas & Electric (BGE)",
                "Potomac Electric Power Company (Pepco)",
                "Delmarva Power & Light",
                "Southern Maryland Electric Cooperative (SMECO)",
              ].map((utility, index) => (
                <div key={index} className="bg-white p-6 rounded-lg shadow-md border-l-4 border-[#C41E3A]">
                  <p className="font-semibold text-[#001F3F]">{utility}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
