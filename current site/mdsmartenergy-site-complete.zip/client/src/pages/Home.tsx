import { Link } from "wouter";
import { CheckCircle2, Zap, Leaf, DollarSign, Shield, TrendingDown, Wrench, Building2, Lightbulb, Plug, Sun, BarChart3 } from "lucide-react";

export default function Home() {
  const services = [
    {
      title: "HVAC Tune-Up",
      description: "Optimize your HVAC system for maximum efficiency and lower energy bills.",
      href: "/services/hvac-tune-up",
      icon: Wrench,
    },
    {
      title: "Building Tune-Up",
      description: "Comprehensive evaluations to enhance overall building energy efficiency.",
      href: "/services/building-tune-up",
      icon: Building2,
    },
    {
      title: "Lighting",
      description: "LED upgrades and lighting controls for significant energy savings.",
      href: "/services/lighting",
      icon: Lightbulb,
    },
    {
      title: "Energy Supply",
      description: "Competitive energy procurement and supplier optimization.",
      href: "/services/energy-supply",
      icon: Plug,
    },
    {
      title: "Community Solar",
      description: "Access solar energy benefits without rooftop installation.",
      href: "/services/community-solar",
      icon: Sun,
    },
    {
      title: "Benchmarking Services",
      description: "Track and analyze your building's energy performance.",
      href: "/services/benchmarking",
      icon: BarChart3,
    },
  ];

  const benefits = [
    {
      icon: DollarSign,
      title: "Cost Savings",
      description: "Save up to 10% on energy usage with significant utility bill reductions",
    },
    {
      icon: Shield,
      title: "Equipment Lifespan",
      description: "Extend HVAC system life through proper maintenance and tune-ups",
    },
    {
      icon: Leaf,
      title: "Environmental Impact",
      description: "Reduce carbon footprint and support Maryland's sustainability goals",
    },
    {
      icon: CheckCircle2,
      title: "No Cost",
      description: "100% covered by EmPOWER Maryland program - zero out-of-pocket expense",
    },
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="relative text-white py-20 md:py-32 bg-cover bg-center bg-fixed" style={{
        backgroundImage: 'url(https://d2xsxph8kpxj0f.cloudfront.net/310519663343730640/awFmGyrrsiLMgk7vjDfYKy/hvac-hero-background-bftep6ZpSEoLa2Dz4RgV5D.webp)'
      }}>
        <div className="absolute inset-0 bg-black/50"></div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl">
            <div className="inline-block bg-[#C41E3A] text-white px-4 py-2 rounded-full text-sm font-semibold mb-6 border-2 border-[#FFB81C]">
              Serving BGE, Pepco, Delmarva Power & SMECO
            </div>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
              No-Cost Energy Efficiency Solutions for Your Business
            </h1>
            <p className="text-lg md:text-xl text-gray-200 mb-8 leading-relaxed">
              Optimize your building's energy performance through EmPOWER Maryland programs. 
              Save money, reduce emissions, and extend equipment lifespan—all at no cost to you.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/contact" className="bg-[#C41E3A] hover:bg-[#A01729] text-white font-bold py-3 px-8 rounded-lg transition-colors text-center inline-block">
                Get Your No-Cost Assessment
              </Link>
              <Link href="/services/hvac-tune-up" className="border-2 border-white text-white hover:bg-white hover:text-[#001F3F] font-bold py-3 px-8 rounded-lg transition-colors text-center inline-block">
                Learn More
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-[#001F3F]">
            Why Choose <span className="text-[#FFB81C]">Maryland Smart Energy</span>?
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {benefits.map((benefit, index) => {
              const Icon = benefit.icon;
              return (
                <div key={index} className="bg-white p-8 rounded-lg shadow-md hover:shadow-lg transition-shadow border-l-4 border-[#FFB81C]">
                  <Icon className="w-12 h-12 text-[#C41E3A] mb-4" />
                  <h3 className="text-lg font-bold text-[#001F3F] mb-3">{benefit.title}</h3>
                  <p className="text-gray-600 text-sm leading-relaxed">{benefit.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Services Overview */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-4 text-[#001F3F]">
            Our <span className="text-[#FFB81C]">Services</span>
          </h2>
          <p className="text-center text-gray-600 mb-12 max-w-2xl mx-auto">
            Comprehensive energy efficiency solutions tailored to your business needs
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => {
              const Icon = service.icon;
              return (
                <Link key={index} href={service.href}>
                  <a className="group">
                    <div className="bg-white border-2 border-gray-200 rounded-lg p-8 hover:border-[#C41E3A] transition-all hover:shadow-lg h-full flex flex-col hover:border-t-4 hover:border-t-[#FFB81C]">
                      <Icon className="w-12 h-12 text-[#C41E3A] mb-4" />
                      <h3 className="text-xl font-bold text-[#001F3F] mb-3 group-hover:text-[#C41E3A] transition-colors">
                        {service.title}
                      </h3>
                      <p className="text-gray-600 text-sm leading-relaxed flex-grow">
                        {service.description}
                      </p>
                      <div className="mt-4 text-[#C41E3A] font-semibold text-sm group-hover:translate-x-2 transition-transform">
                        Learn More →
                      </div>
                    </div>
                  </a>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-[#001F3F] text-white py-16 md:py-24">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to <span className="text-[#FFB81C]">Reduce Your Energy Costs</span>?
          </h2>
          <p className="text-lg text-gray-200 mb-8 max-w-2xl mx-auto">
            Contact us today for a free, no-obligation energy assessment. Our experts will help you 
            identify savings opportunities and guide you through the EmPOWER Maryland program.
          </p>
          <Link href="/contact">
            <a className="inline-block bg-[#C41E3A] hover:bg-[#A01729] text-white font-bold py-4 px-10 rounded-lg transition-colors text-lg">
              Schedule Your Free Assessment
            </a>
          </Link>
        </div>
      </section>

      {/* FAQ Preview */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-[#001F3F]">
            Frequently Asked Questions
          </h2>
          <div className="max-w-3xl mx-auto space-y-6">
            {[
              {
                q: "Are your services really zero cost?",
                a: "Yes! Our energy audits and services qualify for EmPOWER Maryland rebates. We price our services to match the rebate amount, so there's never any out-of-pocket cost to you.",
              },
              {
                q: "Why should I trust your energy audits?",
                a: "Our no-cost audits are covered by your energy company, ensuring trust and zero-risk for you. We are licensed, bonded, and insured.",
              },
              {
                q: "How can your services improve my energy efficiency?",
                a: "Our HVAC and building tune-ups significantly boost energy efficiency by optimizing system performance, improving controls, and identifying energy-saving opportunities.",
              },
            ].map((faq, index) => (
              <div key={index} className="bg-white p-6 rounded-lg border border-gray-200">
                <h3 className="font-bold text-[#001F3F] mb-3">{faq.q}</h3>
                <p className="text-gray-600 text-sm leading-relaxed">{faq.a}</p>
              </div>
            ))}
          </div>
          <div className="text-center mt-12">
            <p className="text-gray-600 mb-4">Have more questions?</p>
            <Link href="/contact">
              <a className="text-[#C41E3A] font-semibold hover:underline">
                Contact us or visit our FAQ page
              </a>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
