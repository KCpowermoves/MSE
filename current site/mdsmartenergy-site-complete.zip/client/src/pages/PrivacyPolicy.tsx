export default function PrivacyPolicy() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="bg-[#001F3F] text-white py-12 md:py-16">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Privacy Policy</h1>
          <p className="text-gray-200">Last updated: March 2026</p>
        </div>
      </section>

      {/* Content Section */}
      <section className="py-12 md:py-16">
        <div className="container mx-auto px-4 max-w-3xl">
          <div className="space-y-8">
            <div>
              <h2 className="text-2xl font-bold text-[#001F3F] mb-4">1. Introduction</h2>
              <p className="text-gray-700 leading-relaxed">
                Maryland Smart Energy ("we," "us," "our," or "Company") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website and use our services.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-[#001F3F] mb-4">2. Information We Collect</h2>
              <p className="text-gray-700 leading-relaxed mb-4">We may collect information about you in a variety of ways. The information we may collect on the site includes:</p>
              <ul className="list-disc list-inside text-gray-700 space-y-2 ml-4">
                <li><strong>Personal Data:</strong> Name, email address, phone number, mailing address, and other contact information you voluntarily provide through forms or inquiries.</li>
                <li><strong>Business Information:</strong> Company name, building address, energy usage data, and other information related to your energy efficiency needs.</li>
                <li><strong>Technical Data:</strong> IP address, browser type, operating system, referring URLs, and pages visited on our website.</li>
                <li><strong>Cookies and Tracking:</strong> Information collected through cookies, web beacons, and similar tracking technologies.</li>
              </ul>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-[#001F3F] mb-4">3. How We Use Your Information</h2>
              <p className="text-gray-700 leading-relaxed mb-4">We use the information we collect in the following ways:</p>
              <ul className="list-disc list-inside text-gray-700 space-y-2 ml-4">
                <li>To provide, operate, and maintain our services</li>
                <li>To respond to your inquiries and provide customer support</li>
                <li>To send you promotional communications, newsletters, and updates (with your consent)</li>
                <li>To improve and optimize our website and services</li>
                <li>To analyze usage patterns and trends</li>
                <li>To comply with legal obligations and protect our rights</li>
                <li>To process energy efficiency assessments and provide recommendations</li>
              </ul>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-[#001F3F] mb-4">4. Disclosure of Your Information</h2>
              <p className="text-gray-700 leading-relaxed mb-4">We may share your information in the following circumstances:</p>
              <ul className="list-disc list-inside text-gray-700 space-y-2 ml-4">
                <li><strong>Service Providers:</strong> With third-party service providers who assist us in operating our website and conducting our business.</li>
                <li><strong>Partner Programs:</strong> With EmPOWER Maryland and other energy efficiency programs to process your applications and benefits.</li>
                <li><strong>Legal Requirements:</strong> When required by law or to protect our legal rights.</li>
                <li><strong>Business Transfers:</strong> In connection with any merger, sale, or acquisition of our company.</li>
              </ul>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-[#001F3F] mb-4">5. Security of Your Information</h2>
              <p className="text-gray-700 leading-relaxed">
                We implement appropriate technical and organizational measures to protect your personal information against unauthorized access, alteration, disclosure, or destruction. However, no method of transmission over the Internet is 100% secure, and we cannot guarantee absolute security.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-[#001F3F] mb-4">6. Your Rights and Choices</h2>
              <p className="text-gray-700 leading-relaxed mb-4">You have the following rights regarding your personal information:</p>
              <ul className="list-disc list-inside text-gray-700 space-y-2 ml-4">
                <li>Access your personal information</li>
                <li>Correct inaccurate information</li>
                <li>Request deletion of your information</li>
                <li>Opt-out of marketing communications</li>
                <li>Disable cookies through your browser settings</li>
              </ul>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-[#001F3F] mb-4">7. Cookies and Tracking Technologies</h2>
              <p className="text-gray-700 leading-relaxed">
                Our website uses cookies and similar tracking technologies to enhance your experience. You can control cookie preferences through your browser settings. Please note that disabling cookies may affect the functionality of our website.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-[#001F3F] mb-4">8. Third-Party Links</h2>
              <p className="text-gray-700 leading-relaxed">
                Our website may contain links to third-party websites. We are not responsible for the privacy practices of these external sites. We encourage you to review their privacy policies before providing any personal information.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-[#001F3F] mb-4">9. Children's Privacy</h2>
              <p className="text-gray-700 leading-relaxed">
                Our website is not intended for children under the age of 13. We do not knowingly collect personal information from children under 13. If we become aware that we have collected such information, we will take steps to delete it promptly.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-[#001F3F] mb-4">10. Changes to This Privacy Policy</h2>
              <p className="text-gray-700 leading-relaxed">
                We may update this Privacy Policy from time to time to reflect changes in our practices or for other operational, legal, or regulatory reasons. We will notify you of any material changes by posting the updated policy on our website and updating the "Last updated" date.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-[#001F3F] mb-4">11. Contact Us</h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                If you have questions about this Privacy Policy or our privacy practices, please contact us at:
              </p>
              <div className="bg-gray-50 p-6 rounded-lg">
                <p className="text-gray-700"><strong>Maryland Smart Energy</strong></p>
                <p className="text-gray-700">Email: <a href="mailto:service@mdsmartenergy.com" className="text-[#C41E3A] hover:underline">service@mdsmartenergy.com</a></p>
                <p className="text-gray-700">Phone: <a href="tel:+13018887090" className="text-[#C41E3A] hover:underline">(301) 888-7090</a></p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
