export default function TermsOfService() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="bg-[#001F3F] text-white py-12 md:py-16">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Terms of Service</h1>
          <p className="text-gray-200">Last updated: March 2026</p>
        </div>
      </section>

      {/* Content Section */}
      <section className="py-12 md:py-16">
        <div className="container mx-auto px-4 max-w-3xl">
          <div className="space-y-8">
            <div>
              <h2 className="text-2xl font-bold text-[#001F3F] mb-4">1. Agreement to Terms</h2>
              <p className="text-gray-700 leading-relaxed">
                These Terms of Service ("Terms") constitute a legally binding agreement between you and Maryland Smart Energy ("Company," "we," "us," or "our"). By accessing and using this website and our services, you agree to be bound by these Terms. If you do not agree to abide by the above, please do not use this service.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-[#001F3F] mb-4">2. Use License</h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                Permission is granted to temporarily download one copy of the materials (information or software) on Maryland Smart Energy's website for personal, non-commercial transitory viewing only. This is the grant of a license, not a transfer of title, and under this license you may not:
              </p>
              <ul className="list-disc list-inside text-gray-700 space-y-2 ml-4">
                <li>Modifying or copying the materials</li>
                <li>Using the materials for any commercial purpose or for any public display</li>
                <li>Attempting to decompile or reverse engineer any software contained on the website</li>
                <li>Removing any copyright or other proprietary notations from the materials</li>
                <li>Transferring the materials to another person or "mirroring" the materials on any other server</li>
                <li>Violating any applicable laws or regulations</li>
              </ul>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-[#001F3F] mb-4">3. Disclaimer</h2>
              <p className="text-gray-700 leading-relaxed">
                The materials on Maryland Smart Energy's website are provided on an 'as is' basis. Maryland Smart Energy makes no warranties, expressed or implied, and hereby disclaims and negates all other warranties including, without limitation, implied warranties or conditions of merchantability, fitness for a particular purpose, or non-infringement of intellectual property or other violation of rights.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-[#001F3F] mb-4">4. Limitations</h2>
              <p className="text-gray-700 leading-relaxed">
                In no event shall Maryland Smart Energy or its suppliers be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use the materials on Maryland Smart Energy's website, even if Maryland Smart Energy or an authorized representative has been notified orally or in writing of the possibility of such damage.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-[#001F3F] mb-4">5. Accuracy of Materials</h2>
              <p className="text-gray-700 leading-relaxed">
                The materials appearing on Maryland Smart Energy's website could include technical, typographical, or photographic errors. Maryland Smart Energy does not warrant that any of the materials on its website are accurate, complete, or current. Maryland Smart Energy may make changes to the materials contained on its website at any time without notice.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-[#001F3F] mb-4">6. Materials and Content</h2>
              <p className="text-gray-700 leading-relaxed">
                The materials on Maryland Smart Energy's website are protected by applicable copyright and trademark law. You may not reproduce, distribute, transmit, display, or perform any content on this website without the prior written permission of Maryland Smart Energy.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-[#001F3F] mb-4">7. Links</h2>
              <p className="text-gray-700 leading-relaxed">
                Maryland Smart Energy has not reviewed all of the sites linked to its website and is not responsible for the contents of any such linked site. The inclusion of any link does not imply endorsement by Maryland Smart Energy of the site. Use of any such linked website is at the user's own risk.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-[#001F3F] mb-4">8. Modifications</h2>
              <p className="text-gray-700 leading-relaxed">
                Maryland Smart Energy may revise these terms of service for its website at any time without notice. By using this website, you are agreeing to be bound by the then current version of these terms of service.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-[#001F3F] mb-4">9. Governing Law</h2>
              <p className="text-gray-700 leading-relaxed">
                These terms and conditions are governed by and construed in accordance with the laws of the State of Maryland, and you irrevocably submit to the exclusive jurisdiction of the courts in that location.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-[#001F3F] mb-4">10. User Conduct</h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                You agree that you will not use the website for any purpose that is unlawful or prohibited by these terms, including but not limited to:
              </p>
              <ul className="list-disc list-inside text-gray-700 space-y-2 ml-4">
                <li>Harassing or causing distress or inconvenience to any person</li>
                <li>Transmitting obscene or offensive content</li>
                <li>Disrupting the normal flow of dialogue within our website</li>
                <li>Attempting to gain unauthorized access to our systems</li>
                <li>Collecting or tracking personal information of others</li>
              </ul>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-[#001F3F] mb-4">11. Services Disclaimer</h2>
              <p className="text-gray-700 leading-relaxed">
                Maryland Smart Energy provides energy efficiency consulting and program enrollment services. While we strive to provide accurate information and recommendations, energy savings results may vary based on individual circumstances, building conditions, utility rates, and other factors. We do not guarantee specific energy savings or financial returns.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-[#001F3F] mb-4">12. Contact Information</h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                If you have any questions about these Terms of Service, please contact us at:
              </p>
              <div className="bg-gray-50 p-6 rounded-lg">
                <p className="text-gray-700"><strong>Maryland Smart Energy</strong></p>
                <p className="text-gray-700">Email: <a href="mailto:service@mdsmartenergy.com" className="text-[#C41E3A] hover:underline">service@mdsmartenergy.com</a></p>
                <p className="text-gray-700">Phone: <a href="tel:+13018887090" className="text-[#C41E3A] hover:underline">(301) 888-7090</a></p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
