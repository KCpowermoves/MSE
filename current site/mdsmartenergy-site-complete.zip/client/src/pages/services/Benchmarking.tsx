import { Link } from "wouter";
import { CheckCircle2, TrendingDown, BarChart3 } from "lucide-react";
import { useState } from "react";
import ServiceFormModal from "@/components/ServiceFormModal";

export default function Benchmarking() {
  const [isFormOpen, setIsFormOpen] = useState(false);

  const benefits = [
    "Track building energy performance over time",
    "Compare your building to similar facilities",
    "Identify energy-saving opportunities",
    "Meet Maryland BEPS compliance requirements",
    "Demonstrate commitment to sustainability",
    "Benchmark against industry standards",
    "Support decarbonization goals",
    "Access utility data easily",
  ];

  const faqs = [
    {
      q: "What is building energy benchmarking?",
      a: "Benchmarking is the process of measuring and tracking a building's energy consumption and comparing it against past performance and similar buildings. This helps identify where energy is being wasted.",
    },
    {
      q: "Is benchmarking required for my building?",
      a: "Buildings 35,000 square feet and larger must comply with Maryland's Building Energy Performance Standards (BEPS), which requires annual benchmarking and reporting.",
    },
    {
      q: "What tool do you use for benchmarking?",
      a: "We use ENERGY STAR Portfolio Manager, the industry-leading free tool managed by the EPA. It's the same tool used by nearly 25% of U.S. commercial building space.",
    },
    {
      q: "How often do I need to benchmark?",
      a: "Annual benchmarking is required for BEPS compliance. Many organizations benchmark quarterly or monthly to track progress and identify issues quickly.",
    },
    {
      q: "What is third-party verification?",
      a: "Third-party verification means an independent expert reviews your benchmarking data to ensure accuracy. BEPS requires verification every 5 years (first year, then every 5 years after).",
    },
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="relative text-white py-16 md:py-24 bg-cover bg-center" style={{backgroundImage: 'url(https://d2xsxph8kpxj0f.cloudfront.net/310519663343730640/awFmGyrrsiLMgk7vjDfYKy/benchmarking-hero-black-female-CpUeb7ZXes37iLhv6SrJae.webp)', backgroundAttachment: 'fixed'}}>
        <div className="absolute inset-0 bg-black/50"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Energy Benchmarking Services</h1>
            <p className="text-lg text-gray-200 mb-8">
              Track, analyze, and optimize your building's energy performance. Meet Maryland BEPS 
              compliance requirements and discover savings opportunities through professional benchmarking.
            </p>
            <button
              onClick={() => setIsFormOpen(true)}
              className="inline-block bg-[#C41E3A] hover:bg-[#A01729] text-white font-bold py-3 px-8 rounded-lg transition-colors"
            >
              Schedule Your Free Benchmarking Consultation
            </button>
          </div>
        </div>
      </section>

      {/* Overview Section */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-[#001F3F] mb-6">
                Understand Your Building's Energy Performance
              </h2>
              <p className="text-gray-600 mb-4 leading-relaxed">
                Energy benchmarking is the foundation of any energy efficiency program. By measuring and 
                tracking your building's energy consumption, you gain visibility into where energy is being 
                used and where improvements can be made.
              </p>
              <p className="text-gray-600 mb-6 leading-relaxed">
                We help you set up benchmarking in ENERGY STAR Portfolio Manager, collect and verify your 
                energy data, and analyze results to identify savings opportunities. We also ensure compliance 
                with Maryland's Building Energy Performance Standards (BEPS).
              </p>
              <div className="bg-blue-50 border-l-4 border-[#C41E3A] p-6 rounded">
                <p className="text-[#001F3F] font-semibold">
                  No-Cost Benchmarking Services
                </p>
                <p className="text-gray-600 text-sm mt-2">
                  Benchmarking and verification services are covered by EmPOWER Maryland rebates.
                </p>
              </div>
            </div>
            <div className="rounded-lg overflow-hidden h-96 shadow-lg">
              <img src="https://d2xsxph8kpxj0f.cloudfront.net/310519663343730640/awFmGyrrsiLMgk7vjDfYKy/benchmarking-side_33e5e0f7.jpg" alt="Energy Benchmarking" className="w-full h-full object-cover" />
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-[#001F3F] mb-12">
            Benefits of Energy Benchmarking
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {benefits.map((benefit, index) => (
              <div key={index} className="flex gap-4">
                <CheckCircle2 className="w-6 h-6 text-[#C41E3A] flex-shrink-0 mt-1" />
                <p className="text-gray-700 font-medium">{benefit}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* BEPS Section */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-[#001F3F] mb-12">
            Maryland Building Energy Performance Standards (BEPS)
          </h2>
          <div className="max-w-4xl mx-auto">
            <div className="bg-white rounded-lg shadow-md p-8 border-l-4 border-[#C41E3A]">
              <h3 className="text-2xl font-bold text-[#001F3F] mb-6">What You Need to Know</h3>
              <div className="space-y-6">
                <div>
                  <h4 className="font-bold text-[#001F3F] mb-2">Who is Covered?</h4>
                  <p className="text-gray-600">Buildings 35,000 square feet and larger in Maryland must comply with BEPS requirements.</p>
                </div>
                <div>
                  <h4 className="font-bold text-[#001F3F] mb-2">Reporting Deadline</h4>
                  <p className="text-gray-600">Annual benchmarking reports are due June 1st each year, starting June 1, 2025.</p>
                </div>
                <div>
                  <h4 className="font-bold text-[#001F3F] mb-2">Third-Party Verification</h4>
                  <p className="text-gray-600">Buildings must submit third-party verified benchmarking reports to the Maryland Department of Environment on June 1, 2026, and every five years thereafter.</p>
                </div>
                <div>
                  <h4 className="font-bold text-[#001F3F] mb-2">Our Support</h4>
                  <p className="text-gray-600">We handle all aspects of BEPS compliance, including data collection, benchmarking, verification, and reporting to ensure your building meets all requirements.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-[#001F3F] mb-12">
            Our Benchmarking Process
          </h2>
          <div className="max-w-4xl mx-auto">
            <div className="space-y-8">
              {[
                {
                  step: "1",
                  title: "Initial Consultation",
                  description: "We discuss your building, energy goals, and BEPS compliance requirements.",
                },
                {
                  step: "2",
                  title: "Data Collection",
                  description: "We gather energy consumption data from your utility companies and building systems.",
                },
                {
                  step: "3",
                  title: "Portfolio Manager Setup",
                  description: "We set up your building in ENERGY STAR Portfolio Manager and enter all necessary data.",
                },
                {
                  step: "4",
                  title: "Analysis & Reporting",
                  description: "We analyze your building's performance and provide a detailed report with insights and recommendations.",
                },
                {
                  step: "5",
                  title: "Third-Party Verification",
                  description: "We arrange for independent verification of your benchmarking data if required.",
                },
                {
                  step: "6",
                  title: "Compliance Reporting",
                  description: "We submit all required reports to ensure your building meets BEPS and other compliance requirements.",
                },
              ].map((item, index) => (
                <div key={index} className="flex gap-6">
                  <div className="flex-shrink-0">
                    <div className="flex items-center justify-center h-12 w-12 rounded-md bg-[#C41E3A] text-white font-bold">
                      {item.step}
                    </div>
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-[#001F3F] mb-2">{item.title}</h3>
                    <p className="text-gray-600 leading-relaxed">{item.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-[#001F3F] mb-12">
            Frequently Asked Questions
          </h2>
          <div className="max-w-3xl mx-auto space-y-6">
            {faqs.map((faq, index) => (
              <div key={index} className="bg-white p-6 rounded-lg border border-gray-200">
                <h3 className="font-bold text-[#001F3F] mb-3">{faq.q}</h3>
                <p className="text-gray-600 text-sm leading-relaxed">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-[#001F3F] text-white py-16 md:py-24">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Get Your Building Benchmarked Today
          </h2>
          <p className="text-lg text-gray-200 mb-8 max-w-2xl mx-auto">
            Schedule a free consultation to discuss your building's benchmarking needs and BEPS compliance requirements.
          </p>
          <button
            onClick={() => setIsFormOpen(true)}
            className="inline-block bg-[#C41E3A] hover:bg-[#A01729] text-white font-bold py-4 px-10 rounded-lg transition-colors text-lg"
          >
            Schedule Your Free Consultation
          </button>
        </div>
      </section>

      <ServiceFormModal
        isOpen={isFormOpen}
        onClose={() => setIsFormOpen(false)}
        serviceName="Benchmarking Services"
        isPaperform={false}
      />
    </div>
  );
}
