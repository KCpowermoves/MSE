import { Link } from "wouter";
import { CheckCircle2, Building2, TrendingDown } from "lucide-react";
import { useState } from "react";
import ServiceFormModal from "@/components/ServiceFormModal";

export default function BuildingTuneUp() {
  const [isFormOpen, setIsFormOpen] = useState(false);

  const improvements = [
    "HVAC system optimization and controls adjustment",
    "Building envelope inspection and sealing",
    "Lighting system evaluation and upgrades",
    "Water heating system optimization",
    "Compressed air leak detection and repair",
    "Refrigeration system improvements",
    "Building automation and controls tuning",
    "Energy management system implementation",
  ];

  const faqs = [
    {
      q: "What's the difference between HVAC tune-up and building tune-up?",
      a: "HVAC tune-up focuses specifically on heating and cooling systems, while building tune-up is a comprehensive evaluation of all building systems including HVAC, lighting, controls, and envelope.",
    },
    {
      q: "How long does a building tune-up take?",
      a: "Building tune-ups typically take 1-3 days depending on building size and complexity. We work with your schedule to minimize disruption.",
    },
    {
      q: "Will the tune-up disrupt my business operations?",
      a: "We schedule work during off-hours or low-activity periods whenever possible to minimize disruption to your business.",
    },
    {
      q: "What happens after the tune-up?",
      a: "We provide a detailed report with findings, recommendations, and estimated savings. We also help you apply for any additional EmPOWER Maryland incentives.",
    },
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="relative text-white py-16 md:py-24 bg-cover bg-center" style={{backgroundImage: 'url(https://d2xsxph8kpxj0f.cloudfront.net/310519663343730640/awFmGyrrsiLMgk7vjDfYKy/building-tuneup-hero_ffe89aca.jpg)', backgroundAttachment: 'fixed'}}>
        <div className="absolute inset-0 bg-black/50"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Building Tune-Up Services</h1>
            <p className="text-lg text-gray-200 mb-8">
              Comprehensive evaluations and adjustments to enhance the overall energy efficiency 
              of your entire building. Discover savings across all building systems.
            </p>
            <button
              onClick={() => setIsFormOpen(true)}
              className="inline-block bg-[#C41E3A] hover:bg-[#A01729] text-white font-bold py-3 px-8 rounded-lg transition-colors"
            >
              Schedule Your Free Assessment
            </button>
          </div>
        </div>
      </section>

      {/* Overview Section */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-[#001F3F] mb-6">
                Comprehensive Building Optimization
              </h2>
              <p className="text-gray-600 mb-4 leading-relaxed">
                A building tune-up goes beyond HVAC to evaluate and optimize all major energy-consuming systems 
                in your facility. Our expert technicians conduct a thorough analysis of your building's performance 
                and identify opportunities for improvement.
              </p>
              <p className="text-gray-600 mb-6 leading-relaxed">
                From HVAC and lighting to controls and building envelope, we ensure every system works together 
                efficiently to minimize energy consumption and operating costs.
              </p>
              <div className="bg-blue-50 border-l-4 border-[#C41E3A] p-6 rounded">
                <p className="text-[#001F3F] font-semibold">
                  Typical Savings: 5-15% on Energy Costs
                </p>
                <p className="text-gray-600 text-sm mt-2">
                  Building tune-ups often identify multiple improvement opportunities that compound to create significant savings.
                </p>
              </div>
            </div>
            <div className="rounded-lg overflow-hidden h-96 shadow-lg">
              <img src="https://d2xsxph8kpxj0f.cloudfront.net/310519663343730640/awFmGyrrsiLMgk7vjDfYKy/building-tuneup-side_568cd548.jpg" alt="Building Tune-Up" className="w-full h-full object-cover" />
            </div>
          </div>
        </div>
      </section>

      {/* Improvements Section */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-[#001F3F] mb-12">
            What We Evaluate & Improve
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {improvements.map((improvement, index) => (
              <div key={index} className="flex gap-4">
                <CheckCircle2 className="w-6 h-6 text-[#C41E3A] flex-shrink-0 mt-1" />
                <p className="text-gray-700 font-medium">{improvement}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-[#001F3F] mb-12">
            Our Building Tune-Up Process
          </h2>
          <div className="max-w-4xl mx-auto">
            <div className="space-y-8">
              {[
                {
                  step: "1",
                  title: "Initial Assessment",
                  description: "We review your building's energy history, systems, and operational patterns to understand your unique situation.",
                },
                {
                  step: "2",
                  title: "On-Site Evaluation",
                  description: "Our technicians conduct a comprehensive inspection of all major building systems and identify optimization opportunities.",
                },
                {
                  step: "3",
                  title: "System Adjustments",
                  description: "We make necessary adjustments and improvements to optimize system performance and efficiency.",
                },
                {
                  step: "4",
                  title: "Detailed Report",
                  description: "We provide a comprehensive report with findings, recommendations, and projected savings for each improvement.",
                },
              ].map((item, index) => (
                <div key={index} className="flex gap-6">
                  <div className="flex-shrink-0">
                    <div className="flex items-center justify-center h-12 w-12 rounded-md bg-[#C41E3A] text-white font-bold">
                      {item.step}
                    </div>
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-[#001F3F] mb-2">{item.title}</h3>
                    <p className="text-gray-600 leading-relaxed">{item.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-[#001F3F] mb-12">
            Key Benefits
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            {[
              {
                title: "Reduce Operating Costs",
                description: "Identify and eliminate energy waste across all building systems",
              },
              {
                title: "Improve Comfort",
                description: "Better temperature control and indoor air quality for occupants",
              },
              {
                title: "Extend Equipment Life",
                description: "Proper maintenance and optimization extend system lifespan",
              },
            ].map((benefit, index) => (
              <div key={index} className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-lg font-bold text-[#001F3F] mb-3">{benefit.title}</h3>
                <p className="text-gray-600 text-sm leading-relaxed">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-[#001F3F] mb-12">
            Frequently Asked Questions
          </h2>
          <div className="max-w-3xl mx-auto space-y-6">
            {faqs.map((faq, index) => (
              <div key={index} className="bg-white p-6 rounded-lg border border-gray-200">
                <h3 className="font-bold text-[#001F3F] mb-3">{faq.q}</h3>
                <p className="text-gray-600 text-sm leading-relaxed">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-[#001F3F] text-white py-16 md:py-24">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Unlock Your Building's Full Efficiency Potential
          </h2>
          <p className="text-lg text-gray-200 mb-8 max-w-2xl mx-auto">
            Schedule your comprehensive building tune-up today and discover how much you can save.
          </p>
          <button
            onClick={() => setIsFormOpen(true)}
            className="inline-block bg-[#C41E3A] hover:bg-[#A01729] text-white font-bold py-4 px-10 rounded-lg transition-colors text-lg"
          >
            Schedule Your Free Assessment
          </button>
        </div>
      </section>

      <ServiceFormModal
        isOpen={isFormOpen}
        onClose={() => setIsFormOpen(false)}
        serviceName="Building Tune-Up"
        isPaperform={true}
        paperformId="rxtuneupsite"
      />
    </div>
  );
}
