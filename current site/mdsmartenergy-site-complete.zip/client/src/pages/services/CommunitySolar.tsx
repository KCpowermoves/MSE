import { Link } from "wouter";
import { CheckCircle, Sun, Users, DollarSign, Zap } from "lucide-react";
import { useState } from "react";
import ServiceFormModal from "@/components/ServiceFormModal";

export default function CommunitySolar() {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [expandedFaq, setExpandedFaq] = useState<number | null>(null);

  const faqs = [
    {
      question: "What is community solar?",
      answer:
        "Community solar allows you to benefit from solar energy without installing panels on your property. You subscribe to a portion of a shared solar array and receive credits on your energy bill for the electricity it generates.",
    },
    {
      question: "How much can I save with community solar?",
      answer:
        "Savings vary based on your subscription size and local electricity rates, but participants typically save 5-15% on their energy bills. Additional incentives may be available through Maryland programs.",
    },
    {
      question: "Do I need to own my home to participate?",
      answer:
        "No, renters and homeowners can both participate in community solar programs. You don't need to own the property or have a suitable roof for solar panels.",
    },
    {
      question: "What happens if the solar array produces more or less energy?",
      answer:
        "Your credits are based on the actual energy produced by your portion of the array. If production is higher, you receive more credits. If lower, you receive fewer credits that month.",
    },
    {
      question: "Can I cancel my community solar subscription?",
      answer:
        "Most community solar programs allow you to cancel with minimal notice, typically 30-60 days. Terms vary by provider, so check your specific agreement.",
    },
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="relative text-white py-16 md:py-24 bg-cover bg-center" style={{backgroundImage: 'url(https://d2xsxph8kpxj0f.cloudfront.net/310519663343730640/awFmGyrrsiLMgk7vjDfYKy/community-solar-hero_57182248.jpg)', backgroundAttachment: 'fixed'}}>
        <div className="absolute inset-0 bg-black/50"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl">
            <div className="inline-block bg-[#C41E3A] text-white text-sm font-semibold px-4 py-2 rounded-full mb-6">
              Renewable Energy
            </div>
            <h1 className="text-5xl md:text-6xl font-bold mb-6">Community Solar</h1>
            <p className="text-xl text-gray-200 mb-8">
              Harness the power of solar energy without the installation costs. Subscribe to a shared solar array and start saving on your energy bills today.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <button
                onClick={() => setIsFormOpen(true)}
                className="inline-block bg-[#C41E3A] hover:bg-[#A01729] text-white font-bold py-3 px-8 rounded-lg transition-colors text-center"
              >
                Get Started Today
              </button>
              <button className="inline-block border-2 border-white text-white hover:bg-white hover:text-[#001F3F] font-bold py-3 px-8 rounded-lg transition-colors">
                Learn More
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Overview Section */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-4xl font-bold text-[#001F3F] mb-12 text-center">
              Go Solar Without the Installation
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              <div>
                <Sun className="w-16 h-16 text-[#C41E3A] mb-4" />
                <h3 className="text-2xl font-bold text-[#001F3F] mb-4">Renewable Energy Access</h3>
                <p className="text-gray-600 leading-relaxed">
                  Community solar makes renewable energy accessible to everyone, regardless of roof space, age, or condition. Benefit from clean solar power without installation hassles.
                </p>
              </div>
              <div>
                <DollarSign className="w-16 h-16 text-[#C41E3A] mb-4" />
                <h3 className="text-2xl font-bold text-[#001F3F] mb-4">Immediate Savings</h3>
                <p className="text-gray-600 leading-relaxed">
                  Start saving on your energy bills immediately upon enrollment. No upfront costs or equipment purchases required. Your subscription is flexible and cancellable.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-[#001F3F] mb-12 text-center">
            Key Benefits of Community Solar
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: CheckCircle,
                title: "No Installation Required",
                description: "Enjoy solar benefits without rooftop panels or installation costs.",
              },
              {
                icon: DollarSign,
                title: "Lower Energy Bills",
                description: "Receive bill credits for electricity generated by your solar share.",
              },
              {
                icon: Users,
                title: "Community Benefit",
                description: "Support local renewable energy infrastructure and environmental sustainability.",
              },
              {
                icon: Zap,
                title: "Flexible Subscriptions",
                description: "Choose your subscription size and adjust or cancel as needed.",
              },
              {
                icon: Sun,
                title: "Environmental Impact",
                description: "Reduce your carbon footprint by supporting clean energy generation.",
              },
              {
                icon: CheckCircle,
                title: "No Maintenance",
                description: "The solar provider handles all maintenance and monitoring.",
              },
            ].map((benefit, index) => {
              const Icon = benefit.icon;
              return (
                <div key={index} className="bg-white p-8 rounded-lg shadow-md hover:shadow-lg transition-shadow">
                  <Icon className="w-12 h-12 text-[#C41E3A] mb-4" />
                  <h3 className="text-xl font-bold text-[#001F3F] mb-3">{benefit.title}</h3>
                  <p className="text-gray-600">{benefit.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-16 md:py-24 bg-blue-50">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-[#001F3F] mb-12 text-center">
            How Community Solar Works
          </h2>
          <div className="max-w-4xl mx-auto">
            <div className="space-y-8">
              {[
                {
                  step: "1",
                  title: "Enroll in a Program",
                  description:
                    "Choose a community solar project and subscribe to a portion of the solar array. No credit check or installation needed.",
                },
                {
                  step: "2",
                  title: "Solar Array Generates Power",
                  description:
                    "The shared solar installation generates clean electricity. Your portion is tracked and credited to your account.",
                },
                {
                  step: "3",
                  title: "Receive Bill Credits",
                  description:
                    "Each month, you receive credits on your utility bill for the electricity your solar share produced.",
                },
                {
                  step: "4",
                  title: "Enjoy Savings",
                  description:
                    "Apply your credits to reduce your monthly energy bill. Savings accumulate over time, providing long-term value.",
                },
              ].map((item, index) => (
                <div key={index} className="flex gap-6">
                  <div className="flex-shrink-0">
                    <div className="flex items-center justify-center h-12 w-12 rounded-full bg-[#C41E3A] text-white font-bold text-lg">
                      {item.step}
                    </div>
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-[#001F3F] mb-2">{item.title}</h3>
                    <p className="text-gray-600">{item.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Maryland Programs Section */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto bg-gradient-to-r from-[#001F3F] to-[#1B4A7F] text-white p-12 rounded-lg">
            <h2 className="text-3xl font-bold mb-6">Maryland Community Solar Programs</h2>
            <p className="text-lg mb-6">
              Maryland offers several community solar programs designed to make renewable energy accessible to all residents and businesses. These programs may include additional incentives and tax credits.
            </p>
            <ul className="space-y-4 mb-8">
              <li className="flex items-start gap-3">
                <CheckCircle className="w-6 h-6 text-[#C41E3A] flex-shrink-0 mt-1" />
                <span>Access to multiple community solar projects across Maryland</span>
              </li>
              <li className="flex items-start gap-3">
                <CheckCircle className="w-6 h-6 text-[#C41E3A] flex-shrink-0 mt-1" />
                <span>Potential state tax credits and incentives</span>
              </li>
              <li className="flex items-start gap-3">
                <CheckCircle className="w-6 h-6 text-[#C41E3A] flex-shrink-0 mt-1" />
                <span>Support for low-income households through special programs</span>
              </li>
              <li className="flex items-start gap-3">
                <CheckCircle className="w-6 h-6 text-[#C41E3A] flex-shrink-0 mt-1" />
                <span>Flexible subscription options for all property types</span>
              </li>
            </ul>
            <button
              onClick={() => setIsFormOpen(true)}
              className="inline-block bg-[#C41E3A] hover:bg-[#A01729] text-white font-bold py-3 px-8 rounded-lg transition-colors"
            >
              Learn About Available Programs
            </button>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-[#001F3F] mb-12 text-center">
            Frequently Asked Questions
          </h2>
          <div className="max-w-3xl mx-auto space-y-4">
            {faqs.map((faq, index) => (
              <div key={index} className="bg-white rounded-lg shadow-md overflow-hidden">
                <button
                  onClick={() => setExpandedFaq(expandedFaq === index ? null : index)}
                  className="w-full px-6 py-4 text-left font-bold text-[#001F3F] hover:bg-gray-50 transition-colors flex justify-between items-center"
                >
                  {faq.question}
                  <span className={`transform transition-transform ${expandedFaq === index ? "rotate-180" : ""}`}>
                    ▼
                  </span>
                </button>
                {expandedFaq === index && (
                  <div className="px-6 py-4 border-t border-gray-200 text-gray-600">
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24 bg-gradient-to-r from-[#C41E3A] to-[#A01729]">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">Ready to Go Solar?</h2>
          <p className="text-xl text-white mb-8 max-w-2xl mx-auto">
            Join thousands of Maryland residents and businesses saving money with community solar. Contact us today to learn about available programs.
          </p>
          <button
            onClick={() => setIsFormOpen(true)}
            className="inline-block bg-white text-[#C41E3A] hover:bg-gray-100 font-bold py-3 px-8 rounded-lg transition-colors"
          >
            Get Your Free Consultation
          </button>
        </div>
      </section>

      <ServiceFormModal
        isOpen={isFormOpen}
        onClose={() => setIsFormOpen(false)}
        serviceName="Community Solar"
        isPaperform={false}
      />
    </div>
  );
}
