import { Link } from "wouter";
import { CheckCircle2, Zap } from "lucide-react";

export default function EnergyEfficiency() {
  const improvements = [
    "Weatherization and air sealing",
    "Insulation upgrades",
    "Window and door replacements",
    "Water heating system optimization",
    "Compressed air system improvements",
    "Refrigeration system upgrades",
    "Building automation and controls",
    "Energy management systems",
    "Steam system optimization",
    "Motor and drive upgrades",
  ];

  const faqs = [
    {
      q: "What is the first step in improving energy efficiency?",
      a: "The first step is an energy audit to identify where energy is being wasted. Our experts will evaluate your building and provide a detailed report with recommendations.",
    },
    {
      q: "How long does it take to see savings?",
      a: "Most improvements show immediate savings on your energy bills. You'll typically see measurable reductions within the first month after improvements are completed.",
    },
    {
      q: "Can I do improvements gradually?",
      a: "Yes! We can help you prioritize improvements based on payback period and your budget. You can implement changes over time.",
    },
    {
      q: "What if my building is already fairly efficient?",
      a: "Even efficient buildings have opportunities for improvement. Our audits often identify unexpected savings opportunities in existing systems.",
    },
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-[#001F3F] to-[#1B4A7F] text-white py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Energy Efficiency Solutions</h1>
            <p className="text-lg text-gray-200 mb-8">
              Comprehensive energy efficiency improvements across all building systems. 
              Reduce operating costs, improve comfort, and support Maryland's sustainability goals.
            </p>
            <Link href="/contact">
              <a className="inline-block bg-[#C41E3A] hover:bg-[#A01729] text-white font-bold py-3 px-8 rounded-lg transition-colors">
                Get Your Free Energy Audit
              </a>
            </Link>
          </div>
        </div>
      </section>

      {/* Overview Section */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-[#001F3F] mb-6">
                Holistic Energy Efficiency
              </h2>
              <p className="text-gray-600 mb-4 leading-relaxed">
                Energy efficiency isn't just about one system—it's about optimizing your entire building. 
                Our comprehensive approach evaluates all major energy-consuming systems and identifies 
                opportunities for improvement.
              </p>
              <p className="text-gray-600 mb-6 leading-relaxed">
                From HVAC and lighting to insulation and controls, we help you create a more efficient, 
                comfortable, and sustainable facility that saves money year after year.
              </p>
              <div className="bg-blue-50 border-l-4 border-[#C41E3A] p-6 rounded">
                <p className="text-[#001F3F] font-semibold">
                  Average Savings: 10-20% on Energy Costs
                </p>
                <p className="text-gray-600 text-sm mt-2">
                  Comprehensive efficiency improvements typically deliver significant, measurable savings.
                </p>
              </div>
            </div>
            <div className="bg-gray-100 rounded-lg p-8 h-96 flex items-center justify-center">
              <div className="text-center">
                <Zap className="w-24 h-24 text-[#C41E3A] mx-auto mb-4" />
                <p className="text-gray-600">Complete Energy Solutions</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Improvements Section */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-[#001F3F] mb-12">
            Energy Efficiency Improvements
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {improvements.map((improvement, index) => (
              <div key={index} className="flex gap-4">
                <CheckCircle2 className="w-6 h-6 text-[#C41E3A] flex-shrink-0 mt-1" />
                <p className="text-gray-700 font-medium">{improvement}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Approach Section */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-[#001F3F] mb-12">
            Our Energy Efficiency Approach
          </h2>
          <div className="max-w-4xl mx-auto">
            <div className="space-y-8">
              {[
                {
                  step: "1",
                  title: "Comprehensive Energy Audit",
                  description: "We conduct a detailed evaluation of all building systems to identify energy waste and improvement opportunities.",
                },
                {
                  step: "2",
                  title: "Analysis & Recommendations",
                  description: "Our experts analyze the data and provide prioritized recommendations with estimated savings for each improvement.",
                },
                {
                  step: "3",
                  title: "Implementation Planning",
                  description: "We help you develop a phased implementation plan that fits your budget and operational needs.",
                },
                {
                  step: "4",
                  title: "Project Management",
                  description: "We oversee the installation and commissioning of improvements to ensure quality and performance.",
                },
                {
                  step: "5",
                  title: "Performance Verification",
                  description: "We verify that improvements are delivering the projected savings and adjust as needed.",
                },
              ].map((item, index) => (
                <div key={index} className="flex gap-6">
                  <div className="flex-shrink-0">
                    <div className="flex items-center justify-center h-12 w-12 rounded-md bg-[#C41E3A] text-white font-bold">
                      {item.step}
                    </div>
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-[#001F3F] mb-2">{item.title}</h3>
                    <p className="text-gray-600 leading-relaxed">{item.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-[#001F3F] mb-12">
            Frequently Asked Questions
          </h2>
          <div className="max-w-3xl mx-auto space-y-6">
            {faqs.map((faq, index) => (
              <div key={index} className="bg-white p-6 rounded-lg border border-gray-200">
                <h3 className="font-bold text-[#001F3F] mb-3">{faq.q}</h3>
                <p className="text-gray-600 text-sm leading-relaxed">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-[#001F3F] text-white py-16 md:py-24">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Start Your Energy Efficiency Journey Today
          </h2>
          <p className="text-lg text-gray-200 mb-8 max-w-2xl mx-auto">
            Get a comprehensive energy audit and discover all the ways you can reduce costs and improve your facility.
          </p>
          <Link href="/contact">
            <a className="inline-block bg-[#C41E3A] hover:bg-[#A01729] text-white font-bold py-4 px-10 rounded-lg transition-colors text-lg">
              Schedule Your Free Energy Audit
            </a>
          </Link>
        </div>
      </section>
    </div>
  );
}
