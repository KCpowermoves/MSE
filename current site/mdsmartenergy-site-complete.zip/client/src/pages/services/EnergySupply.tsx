import { Link } from "wouter";
import { CheckCircle, TrendingDown, Zap, Shield, BarChart3 } from "lucide-react";
import { useState } from "react";
import ServiceFormModal from "@/components/ServiceFormModal";

export default function EnergySupply() {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [expandedFaq, setExpandedFaq] = useState<number | null>(null);

  const faqs = [
    {
      question: "What is energy supply deregulation?",
      answer:
        "In deregulated markets like Maryland, you can choose your electricity supplier while your utility handles delivery. This creates competition and can lead to better rates and service options.",
    },
    {
      question: "Can I switch energy suppliers?",
      answer:
        "Yes, in Maryland's deregulated areas (BGE, Pepco, Delmarva Power, SMECO territories), you can choose your energy supplier. Switching is simple and there are no fees or service interruptions.",
    },
    {
      question: "How much can I save by switching suppliers?",
      answer:
        "Savings vary based on current market rates and your usage patterns. Many customers save 10-25% by choosing competitive suppliers. We help you compare options to find the best deal.",
    },
    {
      question: "What are the different energy supply options?",
      answer:
        "Options include fixed-rate plans (stable pricing), variable-rate plans (market-based), green energy plans (renewable sources), and time-of-use plans (lower rates during off-peak hours).",
    },
    {
      question: "Is my service guaranteed if I switch suppliers?",
      answer:
        "Yes, your utility company continues to deliver electricity and maintain the grid. Switching suppliers doesn't affect service reliability—you have the same delivery infrastructure.",
    },
    {
      question: "Can I switch back to my utility company?",
      answer:
        "Absolutely. You can switch suppliers anytime without penalties. If you want to return to your utility company, you can do so during the next billing cycle.",
    },
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="relative text-white py-16 md:py-24 bg-cover bg-center" style={{backgroundImage: 'url(https://d2xsxph8kpxj0f.cloudfront.net/310519663343730640/awFmGyrrsiLMgk7vjDfYKy/energy-supply-hero_ef067b97.jpg)', backgroundAttachment: 'fixed'}}>
        <div className="absolute inset-0 bg-black/50"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl">
            <div className="inline-block bg-[#C41E3A] text-white text-sm font-semibold px-4 py-2 rounded-full mb-6">
              Energy Procurement
            </div>
            <h1 className="text-5xl md:text-6xl font-bold mb-6">Energy Supply Solutions</h1>
            <p className="text-xl text-gray-200 mb-8">
              Take control of your energy costs. Compare suppliers, lock in competitive rates, and choose renewable options that align with your values.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <button
                onClick={() => setIsFormOpen(true)}
                className="inline-block bg-[#C41E3A] hover:bg-[#A01729] text-white font-bold py-3 px-8 rounded-lg transition-colors text-center"
              >
                Get Your Quote
              </button>
              <button className="inline-block border-2 border-white text-white hover:bg-white hover:text-[#001F3F] font-bold py-3 px-8 rounded-lg transition-colors">
                Learn More
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Overview Section */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-4xl font-bold text-[#001F3F] mb-12 text-center">
              Smart Energy Procurement for Maryland Businesses
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              <div>
                <TrendingDown className="w-16 h-16 text-[#C41E3A] mb-4" />
                <h3 className="text-2xl font-bold text-[#001F3F] mb-4">Competitive Pricing</h3>
                <p className="text-gray-600 leading-relaxed">
                  In Maryland's deregulated energy market, you have the power to choose your supplier. We help you navigate options and secure the best rates for your business.
                </p>
              </div>
              <div>
                <Shield className="w-16 h-16 text-[#C41E3A] mb-4" />
                <h3 className="text-2xl font-bold text-[#001F3F] mb-4">Price Stability</h3>
                <p className="text-gray-600 leading-relaxed">
                  Lock in fixed rates to protect your business from market volatility. Predictable energy costs make budgeting easier and reduce financial uncertainty.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-[#001F3F] mb-12 text-center">
            Why Choose Our Energy Supply Services
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: CheckCircle,
                title: "Expert Comparison",
                description: "We analyze multiple suppliers and plans to find the best match for your needs and budget.",
              },
              {
                icon: TrendingDown,
                title: "Cost Savings",
                description: "Competitive rates and smart procurement strategies reduce your energy expenses significantly.",
              },
              {
                icon: Zap,
                title: "Renewable Options",
                description: "Choose green energy plans that support clean power generation and reduce your carbon footprint.",
              },
              {
                icon: BarChart3,
                title: "Transparent Reporting",
                description: "Detailed analysis and reporting help you understand your energy usage and savings.",
              },
              {
                icon: Shield,
                title: "Contract Management",
                description: "We handle contract negotiations and ensure favorable terms for your business.",
              },
              {
                icon: CheckCircle,
                title: "Ongoing Support",
                description: "Continuous monitoring and optimization ensure you maintain the best rates over time.",
              },
            ].map((benefit, index) => {
              const Icon = benefit.icon;
              return (
                <div key={index} className="bg-white p-8 rounded-lg shadow-md hover:shadow-lg transition-shadow">
                  <Icon className="w-12 h-12 text-[#C41E3A] mb-4" />
                  <h3 className="text-xl font-bold text-[#001F3F] mb-3">{benefit.title}</h3>
                  <p className="text-gray-600">{benefit.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Service Areas Section */}
      <section className="py-16 md:py-24 bg-blue-50">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-[#001F3F] mb-12 text-center">
            We Serve Maryland's Deregulated Markets
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {[
              {
                name: "BGE Territory",
                description: "Baltimore Gas and Electric service area covering central Maryland",
              },
              {
                name: "Pepco Territory",
                description: "Potomac Electric Power Company serving Washington DC metro area",
              },
              {
                name: "Delmarva Power",
                description: "Delmarva Power & Light serving southern Maryland and Delaware",
              },
              {
                name: "SMECO",
                description: "Southern Maryland Electric Cooperative serving Charles and surrounding counties",
              },
            ].map((area, index) => (
              <div key={index} className="bg-white p-8 rounded-lg shadow-md">
                <h3 className="text-xl font-bold text-[#001F3F] mb-2">{area.name}</h3>
                <p className="text-gray-600">{area.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Plan Types Section */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-[#001F3F] mb-12 text-center">
            Energy Supply Plan Options
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {[
              {
                title: "Fixed-Rate Plans",
                features: [
                  "Stable pricing for contract period",
                  "Protection from market fluctuations",
                  "Easy budgeting and forecasting",
                  "Ideal for cost-conscious businesses",
                ],
              },
              {
                title: "Variable-Rate Plans",
                features: [
                  "Rates adjust with market conditions",
                  "Potential savings during low-price periods",
                  "Flexibility to switch suppliers",
                  "Suitable for risk-tolerant businesses",
                ],
              },
              {
                title: "Green Energy Plans",
                features: [
                  "100% renewable energy sources",
                  "Support for wind and solar projects",
                  "Reduce carbon footprint",
                  "Align with sustainability goals",
                ],
              },
              {
                title: "Time-of-Use Plans",
                features: [
                  "Lower rates during off-peak hours",
                  "Higher rates during peak demand",
                  "Rewards flexible consumption",
                  "Maximum savings for strategic users",
                ],
              },
            ].map((plan, index) => (
              <div key={index} className="bg-gradient-to-br from-blue-50 to-blue-100 p-8 rounded-lg border-l-4 border-[#C41E3A]">
                <h3 className="text-2xl font-bold text-[#001F3F] mb-6">{plan.title}</h3>
                <ul className="space-y-3">
                  {plan.features.map((feature, fIndex) => (
                    <li key={fIndex} className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-[#C41E3A] flex-shrink-0 mt-0.5" />
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-[#001F3F] mb-12 text-center">
            Frequently Asked Questions
          </h2>
          <div className="max-w-3xl mx-auto space-y-4">
            {faqs.map((faq, index) => (
              <div key={index} className="bg-white rounded-lg shadow-md overflow-hidden">
                <button
                  onClick={() => setExpandedFaq(expandedFaq === index ? null : index)}
                  className="w-full px-6 py-4 text-left font-bold text-[#001F3F] hover:bg-gray-50 transition-colors flex justify-between items-center"
                >
                  {faq.question}
                  <span className={`transform transition-transform ${expandedFaq === index ? "rotate-180" : ""}`}>
                    ▼
                  </span>
                </button>
                {expandedFaq === index && (
                  <div className="px-6 py-4 border-t border-gray-200 text-gray-600">
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24 bg-gradient-to-r from-[#C41E3A] to-[#A01729]">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">Ready to Optimize Your Energy Costs?</h2>
          <p className="text-xl text-white mb-8 max-w-2xl mx-auto">
            Let us help you navigate Maryland's energy market and find the best supplier and rates for your business.
          </p>
          <button
            onClick={() => setIsFormOpen(true)}
            className="inline-block bg-white text-[#C41E3A] hover:bg-gray-100 font-bold py-3 px-8 rounded-lg transition-colors"
          >
            Get Your Free Energy Analysis
          </button>
        </div>
      </section>

      <ServiceFormModal
        isOpen={isFormOpen}
        onClose={() => setIsFormOpen(false)}
        serviceName="Energy Supply"
        isPaperform={false}
      />
    </div>
  );
}
