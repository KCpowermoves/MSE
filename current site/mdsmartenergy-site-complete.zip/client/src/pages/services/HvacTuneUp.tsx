import { CheckCircle2, Zap, DollarSign, Shield, TrendingDown } from "lucide-react";
import { useState } from "react";
import ServiceFormModal from "@/components/ServiceFormModal";

export default function HvacTuneUp() {
  const [isFormOpen, setIsFormOpen] = useState(false);

  const benefits = [
    "Save 5% to 20% on energy costs",
    "Enhance comfort and safety for occupants",
    "Improve reliability of HVAC equipment",
    "Extend equipment lifespan through preventative maintenance",
    "Reduce environmental impact",
    "Optimize system performance",
  ];

  const incentives = [
    { type: "Units <3 Tons", amount: "$40/ton" },
    { type: "Units 3-20 Tons", amount: "$160/unit" },
    { type: "Units >20-50 Tons", amount: "$260/unit" },
    { type: "Units >50 Tons", amount: "$350/unit" },
  ];

  const faqs = [
    {
      q: "What is included in an HVAC tune-up?",
      a: "Our HVAC tune-ups include system inspection, cleaning, refrigerant checks, filter replacement, control adjustments, and performance testing to ensure optimal efficiency.",
    },
    {
      q: "How often can I get a tune-up?",
      a: "Units are eligible for a tune-up incentive once every 3 years under the EmPOWER Maryland program.",
    },
    {
      q: "What types of HVAC systems are eligible?",
      a: "We service unitary systems (heating, cooling, and fans in one package), direct-expansion rooftop units, and split systems.",
    },
    {
      q: "How long does a tune-up take?",
      a: "Most HVAC tune-ups can be completed in 2-4 hours, depending on system complexity and size.",
    },
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="relative text-white py-16 md:py-24 bg-cover bg-center" style={{backgroundImage: 'url(https://d2xsxph8kpxj0f.cloudfront.net/310519663343730640/awFmGyrrsiLMgk7vjDfYKy/hvac-tune-up-hero_b5edb39e.jpg)', backgroundAttachment: 'fixed'}}>
        <div className="absolute inset-0 bg-black/50"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">HVAC Tune-Up Services</h1>
            <p className="text-lg text-gray-200 mb-8">
              Optimize your business's HVAC system for maximum efficiency and lower energy bills. 
              Our no-cost tune-ups are 100% covered by the EmPOWER Maryland program.
            </p>
            <button
              onClick={() => setIsFormOpen(true)}
              className="inline-block bg-[#C41E3A] hover:bg-[#A01729] text-white font-bold py-3 px-8 rounded-lg transition-colors"
            >
              Schedule Your Free Tune-Up
            </button>
          </div>
        </div>
      </section>

      {/* Overview Section */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-[#001F3F] mb-6">
                What is an HVAC Tune-Up?
              </h2>
              <p className="text-gray-600 mb-4 leading-relaxed">
                An HVAC tune-up is a comprehensive maintenance service designed to optimize your heating, 
                ventilation, and air conditioning system. Our certified technicians perform detailed inspections, 
                cleaning, adjustments, and testing to ensure your system operates at peak efficiency.
              </p>
              <p className="text-gray-600 mb-6 leading-relaxed">
                Regular tune-ups prevent unexpected breakdowns, reduce energy consumption, and extend the lifespan 
                of your equipment—all while saving you money on utility bills.
              </p>
              <div className="bg-blue-50 border-l-4 border-[#C41E3A] p-6 rounded">
                <p className="text-[#001F3F] font-semibold">
                  100% Covered by EmPOWER Maryland
                </p>
                <p className="text-gray-600 text-sm mt-2">
                  There is no cost to participate. Our services are funded by charges already included in your energy bill.
                </p>
              </div>
            </div>
            <div className="rounded-lg overflow-hidden h-96 shadow-lg">
              <img src="https://d2xsxph8kpxj0f.cloudfront.net/310519663343730640/awFmGyrrsiLMgk7vjDfYKy/hvac-tune-up-side_752db4f4.jpg" alt="HVAC Tune-Up" className="w-full h-full object-cover" />
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-[#001F3F] mb-12">
            Key Benefits
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {benefits.map((benefit, index) => (
              <div key={index} className="flex gap-4">
                <CheckCircle2 className="w-6 h-6 text-[#C41E3A] flex-shrink-0 mt-1" />
                <p className="text-gray-700 font-medium">{benefit}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Incentives Section */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-[#001F3F] mb-12">
            Incentive Structure
          </h2>
          <div className="max-w-2xl mx-auto">
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="bg-[#001F3F] text-white p-6">
                <h3 className="text-lg font-bold">EmPOWER Maryland HVAC Tune-Up Incentives</h3>
              </div>
              <div className="divide-y">
                {incentives.map((item, index) => (
                  <div key={index} className="p-6 flex justify-between items-center hover:bg-gray-50">
                    <span className="font-medium text-gray-700">{item.type}</span>
                    <span className="text-[#C41E3A] font-bold text-lg">{item.amount}</span>
                  </div>
                ))}
              </div>
            </div>
            <p className="text-center text-gray-600 text-sm mt-6">
              Incentive amounts vary by utility company. Contact us for specific details for your service territory.
            </p>
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-[#001F3F] mb-12">
            Our Process
          </h2>
          <div className="max-w-4xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {[
                {
                  step: "1",
                  title: "Initial Consultation",
                  description: "We discuss your HVAC system and energy goals",
                },
                {
                  step: "2",
                  title: "System Inspection",
                  description: "Comprehensive evaluation of your HVAC equipment",
                },
                {
                  step: "3",
                  title: "Tune-Up Service",
                  description: "Professional cleaning, adjustments, and testing",
                },
                {
                  step: "4",
                  title: "Report & Follow-Up",
                  description: "Detailed report and recommendations for savings",
                },
              ].map((item, index) => (
                <div key={index} className="text-center">
                  <div className="bg-[#C41E3A] text-white w-12 h-12 rounded-full flex items-center justify-center font-bold text-lg mx-auto mb-4">
                    {item.step}
                  </div>
                  <h3 className="font-bold text-[#001F3F] mb-2">{item.title}</h3>
                  <p className="text-gray-600 text-sm">{item.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-[#001F3F] mb-12">
            Frequently Asked Questions
          </h2>
          <div className="max-w-3xl mx-auto space-y-6">
            {faqs.map((faq, index) => (
              <div key={index} className="bg-white p-6 rounded-lg border border-gray-200">
                <h3 className="font-bold text-[#001F3F] mb-3">{faq.q}</h3>
                <p className="text-gray-600 text-sm leading-relaxed">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-[#001F3F] text-white py-16 md:py-24">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Optimize Your HVAC System?
          </h2>
          <p className="text-lg text-gray-200 mb-8 max-w-2xl mx-auto">
            Contact us today for a free assessment. Our experts will evaluate your system and 
            help you maximize your EmPOWER Maryland benefits.
          </p>
          <button
            onClick={() => setIsFormOpen(true)}
            className="inline-block bg-[#C41E3A] hover:bg-[#A01729] text-white font-bold py-4 px-10 rounded-lg transition-colors text-lg"
          >
            Schedule Your Free Tune-Up
          </button>
        </div>
      </section>

      <ServiceFormModal
        isOpen={isFormOpen}
        onClose={() => setIsFormOpen(false)}
        serviceName="HVAC Tune-Up"
        isPaperform={true}
        paperformId="rxtuneupsite"
      />
    </div>
  );
}
