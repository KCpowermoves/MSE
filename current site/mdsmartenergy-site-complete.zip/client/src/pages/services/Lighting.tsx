import { Link } from "wouter";
import { CheckCircle2, Lightbulb } from "lucide-react";
import { useState } from "react";
import ServiceFormModal from "@/components/ServiceFormModal";

export default function Lighting() {
  const [isFormOpen, setIsFormOpen] = useState(false);

  const upgrades = [
    "LED fixture replacements for interior and exterior lighting",
    "LED exit sign upgrades",
    "Occupancy and motion sensors",
    "Daylight harvesting controls",
    "Dimming and lighting controls",
    "Street lighting LED conversions",
    "Parking lot lighting upgrades",
    "Specialty lighting for retail and hospitality",
  ];

  const faqs = [
    {
      q: "How much can I save with LED lighting?",
      a: "LED lighting typically uses 75% less energy than traditional incandescent bulbs and lasts 25-50 times longer, resulting in significant savings on both energy and replacement costs.",
    },
    {
      q: "Are there incentives for lighting upgrades?",
      a: "Yes! EmPOWER Maryland provides cash incentives for LED fixture upgrades, occupancy controls, and other lighting improvements. We help you maximize these incentives.",
    },
    {
      q: "Will the lighting quality be different?",
      a: "Modern LED lighting provides excellent color quality and brightness. We can match your existing lighting preferences and even improve light quality compared to older systems.",
    },
    {
      q: "What about controls and sensors?",
      a: "Smart lighting controls and occupancy sensors can reduce lighting energy use by an additional 20-30% by ensuring lights are only on when needed.",
    },
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="relative text-white py-16 md:py-24 bg-cover bg-center" style={{backgroundImage: 'url(https://d2xsxph8kpxj0f.cloudfront.net/310519663343730640/awFmGyrrsiLMgk7vjDfYKy/lighting-hero_0becb659.jpg)', backgroundAttachment: 'fixed'}}>
        <div className="absolute inset-0 bg-black/50"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Lighting Efficiency Services</h1>
            <p className="text-lg text-gray-200 mb-8">
              Upgrade to energy-efficient LED lighting and smart controls. Reduce lighting energy costs 
              by up to 75% while improving light quality and safety.
            </p>
            <button
              onClick={() => setIsFormOpen(true)}
              className="inline-block bg-[#C41E3A] hover:bg-[#A01729] text-white font-bold py-3 px-8 rounded-lg transition-colors"
            >
              Schedule Your Free Lighting Audit
            </button>
          </div>
        </div>
      </section>

      {/* Overview Section */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-[#001F3F] mb-6">
                The Power of LED Lighting
              </h2>
              <p className="text-gray-600 mb-4 leading-relaxed">
                LED lighting technology has revolutionized energy efficiency. By replacing traditional 
                incandescent and fluorescent fixtures with LEDs, you can dramatically reduce energy consumption 
                while improving light quality and safety.
              </p>
              <p className="text-gray-600 mb-6 leading-relaxed">
                Combined with smart controls and occupancy sensors, LED lighting systems can reduce your 
                facility's lighting energy costs by 50-75% while providing better illumination.
              </p>
              <div className="bg-blue-50 border-l-4 border-[#C41E3A] p-6 rounded">
                <p className="text-[#001F3F] font-semibold">
                  Up to 75% Energy Savings
                </p>
                <p className="text-gray-600 text-sm mt-2">
                  LED lighting uses significantly less energy than traditional lighting while lasting 25-50 times longer.
                </p>
              </div>
            </div>
            <div className="rounded-lg overflow-hidden h-96 shadow-lg">
              <img src="https://d2xsxph8kpxj0f.cloudfront.net/310519663343730640/awFmGyrrsiLMgk7vjDfYKy/lighting-side_4f35f5b0.jpg" alt="LED Lighting" className="w-full h-full object-cover" />
            </div>
          </div>
        </div>
      </section>

      {/* Upgrades Section */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-[#001F3F] mb-12">
            Lighting Upgrade Options
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {upgrades.map((upgrade, index) => (
              <div key={index} className="flex gap-4">
                <CheckCircle2 className="w-6 h-6 text-[#C41E3A] flex-shrink-0 mt-1" />
                <p className="text-gray-700 font-medium">{upgrade}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-[#001F3F] mb-12">
            Why Choose LED Lighting?
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-5xl mx-auto">
            {[
              {
                title: "Energy Savings",
                description: "75% less energy than incandescent lighting",
              },
              {
                title: "Long Lifespan",
                description: "25-50 times longer than traditional bulbs",
              },
              {
                title: "Better Light Quality",
                description: "Improved brightness and color rendering",
              },
              {
                title: "Reduced Heat",
                description: "Less cooling costs in summer months",
              },
            ].map((benefit, index) => (
              <div key={index} className="bg-white p-6 rounded-lg shadow-md border-t-4 border-[#C41E3A]">
                <h3 className="font-bold text-[#001F3F] mb-3">{benefit.title}</h3>
                <p className="text-gray-600 text-sm leading-relaxed">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Smart Controls Section */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-[#001F3F] mb-12">
            Smart Lighting Controls
          </h2>
          <div className="max-w-4xl mx-auto">
            <p className="text-center text-gray-600 mb-8 leading-relaxed">
              Maximize your savings with intelligent lighting controls that automatically adjust lighting 
              based on occupancy, daylight availability, and time of day.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                {
                  title: "Occupancy Sensors",
                  description: "Automatically turn lights on/off based on room occupancy",
                },
                {
                  title: "Daylight Harvesting",
                  description: "Reduce artificial lighting when natural daylight is available",
                },
                {
                  title: "Scheduling Controls",
                  description: "Program lights to follow your facility's operating schedule",
                },
              ].map((control, index) => (
                <div key={index} className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="font-bold text-[#001F3F] mb-3">{control.title}</h3>
                  <p className="text-gray-600 text-sm leading-relaxed">{control.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-[#001F3F] mb-12">
            Frequently Asked Questions
          </h2>
          <div className="max-w-3xl mx-auto space-y-6">
            {faqs.map((faq, index) => (
              <div key={index} className="bg-white p-6 rounded-lg border border-gray-200">
                <h3 className="font-bold text-[#001F3F] mb-3">{faq.q}</h3>
                <p className="text-gray-600 text-sm leading-relaxed">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-[#001F3F] text-white py-16 md:py-24">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Brighten Your Future with LED Lighting
          </h2>
          <p className="text-lg text-gray-200 mb-8 max-w-2xl mx-auto">
            Get a free lighting audit and discover how much you can save with LED upgrades and smart controls.
          </p>
          <button
            onClick={() => setIsFormOpen(true)}
            className="inline-block bg-[#C41E3A] hover:bg-[#A01729] text-white font-bold py-4 px-10 rounded-lg transition-colors text-lg"
          >
            Schedule Your Free Lighting Audit
          </button>
        </div>
      </section>

      <ServiceFormModal
        isOpen={isFormOpen}
        onClose={() => setIsFormOpen(false)}
        serviceName="Lighting Services"
        isPaperform={false}
      />
    </div>
  );
}
