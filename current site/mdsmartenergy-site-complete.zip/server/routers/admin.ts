import { z } from "zod";
import { publicProcedure, protectedProcedure, router } from "../_core/trpc";
import { getDb } from "../db";
import { users } from "../../drizzle/schema";
import { eq } from "drizzle-orm";

export const adminRouter = router({
  // Check if any admin exists in the system
  hasAdmin: publicProcedure.query(async () => {
    const db = await getDb();
    if (!db) return false;

    const adminUsers = await db
      .select()
      .from(users)
      .where(eq(users.role, "admin"))
      .limit(1);

    return adminUsers.length > 0;
  }),

  // Promote current user to admin (only works if no admin exists yet)
  promoteToAdmin: protectedProcedure.mutation(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    // Check if any admin already exists
    const existingAdmins = await db
      .select()
      .from(users)
      .where(eq(users.role, "admin"))
      .limit(1);

    if (existingAdmins.length > 0) {
      throw new Error("An admin already exists. Only the first user can be promoted to admin.");
    }

    // Promote current user to admin
    if (!ctx.user?.id) {
      throw new Error("User ID not found");
    }

    await db
      .update(users)
      .set({ role: "admin" })
      .where(eq(users.id, ctx.user.id));

    return { success: true, message: "You have been promoted to admin!" };
  }),
});
