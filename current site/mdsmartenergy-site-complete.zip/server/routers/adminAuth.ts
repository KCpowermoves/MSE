import { z } from "zod";
import { publicProcedure, router } from "../_core/trpc";
import { ENV } from "../_core/env";

export const adminAuthRouter = router({
  // Verify admin password
  login: publicProcedure
    .input(z.object({ password: z.string() }))
    .mutation(async ({ input }) => {
      // Simple password comparison (in production, use bcrypt)
      const isValid = input.password === ENV.adminPassword;

      if (!isValid) {
        throw new Error("Invalid password");
      }

      // Return a simple success flag
      // In a real app, you'd set a session cookie or JWT token here
      return { success: true, token: "admin_session" };
    }),
});
