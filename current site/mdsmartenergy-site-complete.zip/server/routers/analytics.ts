import { z } from "zod";
import { protectedProcedure, publicProcedure, router } from "../_core/trpc";
import {
  trackPageView,
  getPageViewStats,
  getContactSubmissions,
  getContactSubmissionStats,
} from "../db";
import crypto from "crypto";

export const analyticsRouter = router({
  // Public: Track a page view
  trackPageView: publicProcedure
    .input(
      z.object({
        path: z.string(),
        referrer: z.string().optional(),
        userAgent: z.string().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      // Hash the IP for privacy
      const ip = ctx.req.headers["x-forwarded-for"] || ctx.req.socket.remoteAddress || "";
      const ipHash = crypto.createHash("sha256").update(ip as string).digest("hex");

      await trackPageView({
        path: input.path,
        referrer: input.referrer,
        userAgent: input.userAgent,
        ipHash,
      });

      return { success: true };
    }),

  // Admin: Get page view statistics
  getPageViewStats: protectedProcedure
    .input(z.object({ days: z.number().default(30) }))
    .query(async ({ input, ctx }) => {
      if (ctx.user?.role !== "admin") {
        throw new Error("Unauthorized");
      }

      const stats = await getPageViewStats(input.days);
      
      // Calculate summary
      const totalViews = stats.length;
      const uniquePaths = new Set(stats.map(s => s.path)).size;
      
      // Group by page
      const pageStats: Record<string, number> = {};
      stats.forEach(view => {
        pageStats[view.path] = (pageStats[view.path] || 0) + 1;
      });

      // Sort by views
      const topPages = Object.entries(pageStats)
        .sort(([, a], [, b]) => b - a)
        .slice(0, 10)
        .map(([path, views]) => ({ path, views }));

      return {
        totalViews,
        uniquePaths,
        topPages,
        rawStats: stats,
      };
    }),

  // Admin: Get contact submission statistics
  getContactStats: protectedProcedure
    .input(z.object({ days: z.number().default(30) }))
    .query(async ({ input, ctx }) => {
      if (ctx.user?.role !== "admin") {
        throw new Error("Unauthorized");
      }

      const stats = await getContactSubmissionStats(input.days);
      return stats;
    }),

  // Admin: Get recent contact submissions
  getRecentSubmissions: protectedProcedure
    .input(z.object({ days: z.number().default(30) }))
    .query(async ({ input, ctx }) => {
      if (ctx.user?.role !== "admin") {
        throw new Error("Unauthorized");
      }

      const submissions = await getContactSubmissions(input.days);
      return submissions;
    }),

  // Admin: Get dashboard summary
  getDashboardSummary: protectedProcedure
    .input(z.object({ days: z.number().default(30) }))
    .query(async ({ input, ctx }) => {
      if (ctx.user?.role !== "admin") {
        throw new Error("Unauthorized");
      }

      const pageStats = await getPageViewStats(input.days);
      const contactStats = await getContactSubmissionStats(input.days);
      const recentSubmissions = await getContactSubmissions(input.days);

      const totalViews = pageStats.length;
      const uniquePaths = new Set(pageStats.map(s => s.path)).size;

      // Top pages
      const pageMap: Record<string, number> = {};
      pageStats.forEach(view => {
        pageMap[view.path] = (pageMap[view.path] || 0) + 1;
      });

      const topPages = Object.entries(pageMap)
        .sort(([, a], [, b]) => b - a)
        .slice(0, 5)
        .map(([path, views]) => ({ path, views }));

      // Recent submissions (last 5)
      const recentLeads = recentSubmissions.slice(0, 5);

      return {
        period: `Last ${input.days} days`,
        pageViews: {
          total: totalViews,
          uniquePages: uniquePaths,
          topPages,
        },
        leads: {
          total: contactStats.total,
          byService: contactStats.byService,
          recent: recentLeads,
        },
      };
    }),
});
