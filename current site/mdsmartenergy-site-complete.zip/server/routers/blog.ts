import { z } from "zod";
import { publicProcedure, router } from "../_core/trpc";
import {
  createBlogPost,
  updateBlogPost,
  deleteBlogPost,
  getBlogPostById,
  getBlogPostBySlug,
  getAllBlogPosts,
  getFeaturedBlogPosts,
} from "../db";

// Validation schemas
const createBlogPostSchema = z.object({
  slug: z.string().min(1),
  title: z.string().min(1),
  excerpt: z.string().optional(),
  content: z.string().min(1),
  category: z.string().optional(),
  author: z.string().optional(),
  featured: z.number().default(0),
  published: z.number().default(0),
  publishedAt: z.date().optional(),
});

const updateBlogPostSchema = z.object({
  id: z.number(),
  slug: z.string().optional(),
  title: z.string().optional(),
  excerpt: z.string().optional(),
  content: z.string().optional(),
  category: z.string().optional(),
  author: z.string().optional(),
  featured: z.number().optional(),
  published: z.number().optional(),
  publishedAt: z.date().optional(),
});

export const blogRouter = router({
  // Admin: Create a new blog post
  create: publicProcedure
    .input(createBlogPostSchema)
    .mutation(async ({ input, ctx }) => {
      if (ctx.user?.role !== "admin") {
        throw new Error("Unauthorized: Only admins can create blog posts");
      }
      
      const post = await createBlogPost({
        ...input,
        author: input.author || ctx.user?.name || "Admin",
      });
      
      return { success: true, message: "Blog post created" };
    }),

  // Admin: Update a blog post
  update: publicProcedure
    .input(updateBlogPostSchema)
    .mutation(async ({ input, ctx }) => {
      if (ctx.user?.role !== "admin") {
        throw new Error("Unauthorized: Only admins can update blog posts");
      }

      const { id, ...data } = input;
      await updateBlogPost(id, data);
      return { success: true, message: "Blog post updated" };
    }),

  // Admin: Delete a blog post
  delete: publicProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input, ctx }) => {
      if (ctx.user?.role !== "admin") {
        throw new Error("Unauthorized: Only admins can delete blog posts");
      }

      await deleteBlogPost(input.id);
      return { success: true, message: "Blog post deleted" };
    }),

  // Admin: Get a single blog post for editing
  getById: publicProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input, ctx }) => {
      if (ctx.user?.role !== "admin") {
        throw new Error("Unauthorized");
      }

      const post = await getBlogPostById(input.id);
      return post;
    }),

  // Public: Get a blog post by slug
  getBySlug: publicProcedure
    .input(z.object({ slug: z.string() }))
    .query(async ({ input }) => {
      const post = await getBlogPostBySlug(input.slug);
      if (!post || !post.published) {
        throw new Error("Post not found");
      }
      return post;
    }),

  // Admin: Get all blog posts (published and draft)
  listAll: publicProcedure.query(async ({ ctx }) => {
    if (ctx.user?.role !== "admin") {
      throw new Error("Unauthorized");
    }

    return getAllBlogPosts(false);
  }),

  // Public: Get published blog posts
  listPublished: publicProcedure.query(async () => {
    return getAllBlogPosts(true);
  }),

  // Public: Get featured blog posts
  getFeatured: publicProcedure
    .input(z.object({ limit: z.number().default(3) }))
    .query(async ({ input }) => {
      return getFeaturedBlogPosts(input.limit);
    }),
});
