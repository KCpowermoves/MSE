import { publicProcedure, router } from "../_core/trpc";
import { z } from "zod";
import { notifyOwner } from "../_core/notification";
import { ENV } from "../_core/env";

export const serviceRequestsRouter = router({
  sendServiceRequest: publicProcedure
    .input(
      z.object({
        to: z.string().email(),
        subject: z.string(),
        body: z.string(),
        affiliateData: z.object({
          affiliate: z.string().optional(),
          ref: z.string().optional(),
          source: z.string().optional(),
        }).optional(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        // Send notification to owner
        await notifyOwner({
          title: input.subject,
          content: input.body,
        });

        // Send emails to all configured addresses
        if (ENV.contactFormEmails && ENV.contactFormEmails.length > 0) {
          const emailPromises = ENV.contactFormEmails.map(email =>
            fetch(`${ENV.forgeApiUrl}/email/send`, {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${ENV.forgeApiKey}`,
              },
              body: JSON.stringify({
                to: email,
                subject: input.subject,
                html: input.body.replace(/\n/g, "<br>"),
              }),
            }).catch(err => {
              console.error(`Failed to send email to ${email}:`, err);
            })
          );
          await Promise.all(emailPromises);
        }

        return {
          success: true,
          message: "Service request submitted successfully",
        };
      } catch (error) {
        console.error("Error sending service request:", error);
        return {
          success: false,
          message: "Failed to submit service request",
        };
      }
    }),
});
