# Maryland Smart Energy - Full Website TODO

## Core Infrastructure
- [x] Set up global layout with header and footer components
- [x] Configure navigation with all pages
- [x] Implement responsive design system
- [x] Set up color scheme (orange #FF6B35 and navy blue #1B3A6B)
- [x] Configure Tailwind CSS with custom theme colors

## Pages & Content
- [x] Initialize project scaffold
- [x] Homepage with hero section and service overview
- [x] HVAC Tune-Up service page
- [x] Building Tune-Up service page
- [x] Lighting service page
- [x] Energy Efficiency service page
- [x] Benchmarking Services page
- [x] About Us page with company info and team
- [x] Contact page with form and contact details
- [x] Blog/Articles listing page
- [x] Individual article pages
- [x] FAQ sections on relevant pages

## Database & Backend
- [ ] Create database schema for blog articles
- [ ] Create database schema for contact form submissions
- [ ] Build tRPC procedures for article management
- [ ] Build tRPC procedures for contact form handling
- [ ] Implement email notification system for contact submissions
- [ ] Set up blog article CRUD operations

## Features
- [ ] Contact form with validation
- [ ] Email notifications to owner on form submission
- [ ] Blog article management system
- [ ] Expandable FAQ components
- [ ] Service request tracking
- [ ] Responsive navigation menu
- [ ] Search functionality for blog (optional)

## Testing & Polish
- [ ] Test all pages on mobile devices
- [ ] Test all pages on tablets
- [ ] Test all pages on desktop
- [ ] Verify all forms work correctly
- [ ] Test email notifications
- [ ] Verify navigation works across all pages
- [ ] Check color contrast and accessibility
- [ ] Optimize images and assets

## Deployment
- [ ] Final checkpoint before publishing
- [ ] Review all content for accuracy
- [ ] Verify all links work correctly

## Recent Updates
- [x] Extract original logo from mdsmartenergy.com
- [x] Replace MSE placeholder logo with original logo
- [x] Consolidate service pages into dropdown menu (HVAC, Building Tune-Up, Lighting, Benchmarking)
- [x] Remove "Energy Efficiency" service page
- [x] Add "Community Solar" service page
- [x] Add "Energy Supply" navigation tab
- [x] Update Layout component with new navigation structure
- [x] Test dropdown menu functionality
- [x] Verify all links work with new navigation

## Current Tasks
- [x] Upload Maryland Smart Energy logo to CDN
- [x] Update Layout component to use new logo
- [x] Remove "Energy Efficiency Solutions" tagline from header
- [x] Update color scheme to navy blue (#001F3F), red (#C41E3A), and gold (#FFB81C)
- [x] Update index.css with new color palette
- [x] Test all pages with new color scheme
- [x] Verify logo displays correctly on all pages


## Blog & Content Review (Complete)
- [x] Review blog posts for relevance to energy efficiency services
- [x] Optimize blog posts for SEO (headings, meta descriptions, keywords)
- [x] Fix blog formatting for readability
- [x] Identify and fix any blog-related errors (nested anchor tags)


## Service Page Image Updates (Complete)
- [x] Generate HVAC Tune-Up hero and side images
- [x] Generate Building Tune-Up hero and side images
- [x] Generate Lighting Service hero and side images
- [x] Generate Energy Supply hero and side images
- [x] Generate Community Solar hero and side images
- [x] Generate Benchmarking Services hero and side images
- [x] Update all service pages with new images
- [x] Verify images are relevant and professional

## Form Integration (In Progress)
- [ ] Add Paperform embed to HVAC Tune-Up service page
- [ ] Add Paperform embed to Building Tune-Up service page
- [ ] Create generic email form for Lighting service page
- [ ] Create generic email form for Energy Supply service page
- [ ] Create generic email form for Community Solar service page
- [ ] Create generic email form for Benchmarking service page
- [ ] Update Contact page form to capture affiliate parameters
- [ ] Ensure all forms pass through URL parameters for affiliate tracking
- [ ] Set up email notifications to service@mdsmartenergy.com
